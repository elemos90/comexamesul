<?php
/**
 * Script de Debug - Sistema Top-3
 * Captura erros detalhados da API
 */

// Ativar exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/app/helpers.php';

// Iniciar sessão
session_start();

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Debug Top-3</title>
    <style>
        body { font-family: monospace; padding: 20px; background: #1e1e1e; color: #d4d4d4; }
        .success { color: #4ec9b0; }
        .error { color: #f48771; }
        .section { background: #252526; padding: 15px; margin: 10px 0; border-left: 3px solid #007acc; }
        h2 { color: #569cd6; }
        pre { background: #1e1e1e; padding: 10px; overflow-x: auto; border: 1px solid #3e3e3e; }
    </style>
</head>
<body>
<h1>🔍 Debug Sistema Top-3</h1>
";

// =========================================
// TESTE 1: Verificar Sessão
// =========================================
echo "<div class='section'>";
echo "<h2>1. Verificar Sessão</h2>";
echo "<p>Session ID: " . session_id() . "</p>";
echo "<p>auth_user_id: " . ($_SESSION['auth_user_id'] ?? '<span class="error">NÃO DEFINIDO</span>') . "</p>";

use App\Utils\Auth;

if (Auth::check()) {
    echo "<p class='success'>✓ Usuário autenticado (ID: " . Auth::id() . ")</p>";
    $user = Auth::user();
    if ($user) {
        echo "<p>Nome: {$user['name']}</p>";
        echo "<p>Role: {$user['role']}</p>";
    }
} else {
    echo "<p class='error'>✗ Usuário NÃO autenticado</p>";
    echo "<p>Fazendo login automático para teste...</p>";
    
    // Simular login
    $_SESSION['auth_user_id'] = 1;
    $_SESSION['auth_user_role'] = 'coordenador';
    echo "<p class='success'>✓ Sessão criada (user_id=1)</p>";
}
echo "</div>";

// =========================================
// TESTE 2: Buscar Júri de Teste
// =========================================
echo "<div class='section'>";
echo "<h2>2. Buscar Júri de Teste</h2>";

use App\Database\Connection;

try {
    $db = Connection::getInstance();
    $stmt = $db->query("
        SELECT id, subject, location, room, exam_date, inicio, fim, vigilantes_capacidade
        FROM juries 
        WHERE inicio IS NOT NULL 
        ORDER BY id DESC 
        LIMIT 1
    ");
    $juri = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($juri) {
        echo "<p class='success'>✓ Júri encontrado: #{$juri['id']}</p>";
        echo "<pre>" . print_r($juri, true) . "</pre>";
        $juriId = $juri['id'];
    } else {
        echo "<p class='error'>✗ Nenhum júri encontrado</p>";
        echo "<p>Crie um júri primeiro!</p>";
        die("</body></html>");
    }
} catch (Exception $e) {
    echo "<p class='error'>✗ Erro ao buscar júri: " . htmlspecialchars($e->getMessage()) . "</p>";
    die("</body></html>");
}
echo "</div>";

// =========================================
// TESTE 3: Simular API top3()
// =========================================
echo "<div class='section'>";
echo "<h2>3. Simular Chamada API top3()</h2>";

try {
    // Simular GET
    $_GET['juri_id'] = $juriId;
    $_GET['papel'] = 'supervisor';
    
    echo "<p>Parâmetros:</p>";
    echo "<pre>juri_id: $juriId\npapel: supervisor</pre>";
    
    // Capturar output e erros
    ob_start();
    
    use App\Controllers\SuggestController;
    
    $controller = new SuggestController();
    $controller->top3();
    
    $output = ob_get_clean();
    
    echo "<p class='success'>✓ Controller executado</p>";
    echo "<h3>Resposta:</h3>";
    echo "<pre>" . htmlspecialchars($output) . "</pre>";
    
    // Tentar decodificar JSON
    $json = json_decode($output, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        echo "<p class='success'>✓ JSON válido</p>";
        
        if (isset($json['ok']) && $json['ok'] === true) {
            echo "<p class='success'>✓ API retornou sucesso!</p>";
            echo "<p>Top-3 retornados: " . count($json['top3'] ?? []) . " docentes</p>";
        } else {
            echo "<p class='error'>✗ API retornou erro: " . ($json['error'] ?? 'Desconhecido') . "</p>";
        }
        
        echo "<h3>JSON Formatado:</h3>";
        echo "<pre>" . json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
    } else {
        echo "<p class='error'>✗ Resposta não é JSON válido</p>";
        echo "<p>Erro: " . json_last_error_msg() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>✗ EXCEÇÃO CAPTURADA:</p>";
    echo "<pre style='color: #f48771;'>";
    echo "Mensagem: " . htmlspecialchars($e->getMessage()) . "\n\n";
    echo "Arquivo: " . $e->getFile() . "\n";
    echo "Linha: " . $e->getLine() . "\n\n";
    echo "Stack Trace:\n" . htmlspecialchars($e->getTraceAsString());
    echo "</pre>";
}

echo "</div>";

// =========================================
// TESTE 4: Verificar Docentes
// =========================================
echo "<div class='section'>";
echo "<h2>4. Verificar Docentes Disponíveis</h2>";

try {
    $stmt = $db->query("
        SELECT id, name, campus, active, available_for_vigilance
        FROM users 
        WHERE role IN ('coordenador', 'membro', 'docente')
        ORDER BY id 
        LIMIT 10
    ");
    $docentes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p>Total de docentes: " . count($docentes) . "</p>";
    
    $elegiveis = array_filter($docentes, function($d) {
        return $d['active'] == 1 && $d['available_for_vigilance'] == 1;
    });
    
    echo "<p>Docentes elegíveis: " . count($elegiveis) . "</p>";
    
    if (count($elegiveis) < 3) {
        echo "<p class='error'>⚠ Menos de 3 docentes elegíveis!</p>";
        echo "<p>Execute: UPDATE users SET active=1, available_for_vigilance=1 WHERE role IN ('coordenador', 'membro', 'docente');</p>";
    }
    
    echo "<h3>Primeiros 10 docentes:</h3>";
    echo "<table border='1' cellpadding='5' style='color: #d4d4d4;'>";
    echo "<tr><th>ID</th><th>Nome</th><th>Campus</th><th>Ativo</th><th>Disponível</th></tr>";
    foreach ($docentes as $d) {
        $activeStyle = $d['active'] ? 'color: #4ec9b0;' : 'color: #f48771;';
        $availStyle = $d['available_for_vigilance'] ? 'color: #4ec9b0;' : 'color: #f48771;';
        echo "<tr>";
        echo "<td>{$d['id']}</td>";
        echo "<td>{$d['name']}</td>";
        echo "<td>{$d['campus']}</td>";
        echo "<td style='$activeStyle'>" . ($d['active'] ? 'SIM' : 'NÃO') . "</td>";
        echo "<td style='$availStyle'>" . ($d['available_for_vigilance'] ? 'SIM' : 'NÃO') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
} catch (Exception $e) {
    echo "<p class='error'>✗ Erro: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "</div>";

// =========================================
// TESTE 5: Verificar Logs do Apache
// =========================================
echo "<div class='section'>";
echo "<h2>5. Últimas Linhas do Error Log</h2>";

$errorLog = 'C:/xampp/apache/logs/error.log';
if (file_exists($errorLog)) {
    $lines = file($errorLog);
    $lastLines = array_slice($lines, -20);
    
    echo "<pre>";
    foreach ($lastLines as $line) {
        if (stripos($line, 'error') !== false || stripos($line, 'warning') !== false) {
            echo "<span class='error'>" . htmlspecialchars($line) . "</span>";
        } else {
            echo htmlspecialchars($line);
        }
    }
    echo "</pre>";
} else {
    echo "<p class='error'>Log não encontrado em: $errorLog</p>";
}

echo "</div>";

echo "
<div class='section'>
<h2>🎯 Diagnóstico</h2>
<p>Se você viu uma EXCEÇÃO acima, esse é o erro que precisa ser corrigido!</p>
<p>Copie a mensagem de erro e a stack trace.</p>
</div>

<p style='text-align: center; margin-top: 30px;'>
    <a href='debug_top3.php' style='color: #4ec9b0;'>Recarregar Debug</a> | 
    <a href='juries/planning' style='color: #4ec9b0;'>Ir para Planning</a>
</p>
</body>
</html>";
