<?php
// Teste básico de PHP
phpinfo();
