<?php
/**
 * TESTE RÁPIDO - Ver se dados foram instalados
 */

require_once __DIR__ . '/../bootstrap.php';

use App\Database\Connection;
use App\Models\Discipline;
use App\Models\ExamLocation;
use App\Models\ExamRoom;

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'>";
echo "<style>body{font-family:sans-serif;padding:20px;background:#f5f5f5;}";
echo ".box{background:white;padding:20px;margin:10px 0;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}";
echo "h2{color:#333;border-bottom:2px solid #667eea;padding-bottom:10px;}";
echo "table{width:100%;border-collapse:collapse;}";
echo "th,td{text-align:left;padding:12px;border-bottom:1px solid #ddd;}";
echo "th{background:#667eea;color:white;}";
echo ".success{color:#10b981;font-weight:bold;}";
echo ".error{color:#ef4444;font-weight:bold;}";
echo "</style></head><body>";

echo "<h1>🔍 Verificação dos Dados Mestres</h1>";

try {
    $db = Connection::getInstance();
    
    // Verificar Disciplinas
    echo "<div class='box'>";
    echo "<h2>📚 Disciplinas</h2>";
    
    try {
        $disciplines = $db->query("SELECT * FROM disciplines ORDER BY code")->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($disciplines)) {
            echo "<p class='success'>✅ " . count($disciplines) . " disciplinas encontradas</p>";
            echo "<table>";
            echo "<tr><th>Código</th><th>Nome</th><th>Status</th></tr>";
            foreach ($disciplines as $d) {
                $status = $d['active'] ? '✅ Ativo' : '❌ Inativo';
                echo "<tr>";
                echo "<td><strong>" . htmlspecialchars($d['code']) . "</strong></td>";
                echo "<td>" . htmlspecialchars($d['name']) . "</td>";
                echo "<td>" . $status . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='error'>❌ Nenhuma disciplina encontrada</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Erro: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // Verificar Locais
    echo "<div class='box'>";
    echo "<h2>📍 Locais</h2>";
    
    try {
        $locations = $db->query("SELECT * FROM exam_locations ORDER BY code")->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($locations)) {
            echo "<p class='success'>✅ " . count($locations) . " locais encontrados</p>";
            echo "<table>";
            echo "<tr><th>Código</th><th>Nome</th><th>Cidade</th><th>Status</th></tr>";
            foreach ($locations as $l) {
                $status = $l['active'] ? '✅ Ativo' : '❌ Inativo';
                echo "<tr>";
                echo "<td><strong>" . htmlspecialchars($l['code']) . "</strong></td>";
                echo "<td>" . htmlspecialchars($l['name']) . "</td>";
                echo "<td>" . htmlspecialchars($l['city'] ?? '-') . "</td>";
                echo "<td>" . $status . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='error'>❌ Nenhum local encontrado</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Erro: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // Verificar Salas
    echo "<div class='box'>";
    echo "<h2>🏛️ Salas</h2>";
    
    try {
        $rooms = $db->query("
            SELECT er.*, el.name as location_name 
            FROM exam_rooms er 
            INNER JOIN exam_locations el ON el.id = er.location_id 
            ORDER BY el.name, er.code
        ")->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($rooms)) {
            echo "<p class='success'>✅ " . count($rooms) . " salas encontradas</p>";
            echo "<table>";
            echo "<tr><th>Código</th><th>Nome</th><th>Local</th><th>Capacidade</th><th>Status</th></tr>";
            foreach ($rooms as $r) {
                $status = $r['active'] ? '✅ Ativo' : '❌ Inativo';
                echo "<tr>";
                echo "<td><strong>" . htmlspecialchars($r['code']) . "</strong></td>";
                echo "<td>" . htmlspecialchars($r['name']) . "</td>";
                echo "<td>" . htmlspecialchars($r['location_name']) . "</td>";
                echo "<td>" . $r['capacity'] . " pessoas</td>";
                echo "<td>" . $status . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='error'>❌ Nenhuma sala encontrada</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Erro: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // Verificar Rotas
    echo "<div class='box'>";
    echo "<h2>🔗 Links para Acessar o Sistema</h2>";
    echo "<p><strong>IMPORTANTE:</strong> Use estes links para acessar o sistema:</p>";
    echo "<ul style='line-height:2;'>";
    echo "<li><a href='index.php?url=/login' style='color:#667eea;text-decoration:none;font-weight:bold;'>🔐 Fazer Login</a></li>";
    echo "<li><a href='index.php?url=/dashboard' style='color:#667eea;text-decoration:none;font-weight:bold;'>📊 Dashboard</a></li>";
    echo "<li><a href='index.php?url=/juries/planning' style='color:#667eea;text-decoration:none;font-weight:bold;'>📅 Planejamento de Júris</a></li>";
    echo "</ul>";
    echo "<p style='background:#fffbeb;padding:10px;border-radius:4px;margin-top:15px;'>";
    echo "<strong>⚠️ Nota:</strong> As páginas de Dados Mestres (Disciplinas, Locais, Salas) estão disponíveis apenas para usuários com role de <strong>Coordenador</strong>.";
    echo "</p>";
    echo "<p style='margin-top:10px;'><strong>Login de teste:</strong><br>";
    echo "Email: <code>coordenador@unilicungo.ac.mz</code><br>";
    echo "Senha: <code>password</code></p>";
    echo "</div>";
    
    echo "<div class='box'>";
    echo "<h2>✅ Conclusão</h2>";
    echo "<p style='font-size:18px;'>Os dados foram instalados corretamente! 🎉</p>";
    echo "<p>Próximo passo: <a href='index.php?url=/login' style='color:#667eea;font-weight:bold;'>Fazer login no sistema</a></p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='box'>";
    echo "<h2 class='error'>❌ Erro de Conexão</h2>";
    echo "<p>Não foi possível conectar ao banco de dados.</p>";
    echo "<p><strong>Erro:</strong> " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</body></html>";
?>
