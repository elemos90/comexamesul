<?php
/**
 * TESTE DE ROTAS - Verificar se sistema de rotas funciona
 */

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'>";
echo "<script src='https://cdn.tailwindcss.com'></script></head><body class='bg-gray-100 p-8'>";

echo "<div class='max-w-4xl mx-auto'>";
echo "<div class='bg-white rounded-lg shadow-lg p-8'>";
echo "<h1 class='text-3xl font-bold text-gray-900 mb-6'>🧪 Teste de Rotas</h1>";

// URLs para testar
$urls = [
    'Login (sem rotas)' => 'login_direto.php',
    'Dashboard (sem rotas)' => 'dashboard_direto.php',
    'Disciplinas (sem rotas)' => 'ver_disciplinas.php',
    '---' => '',
    'Login (com rotas)' => 'index.php?url=/login',
    'Dashboard (com rotas)' => 'index.php?url=/dashboard',
    'Disciplinas (com rotas)' => 'index.php?url=/master-data/disciplines',
    'Locais (com rotas)' => 'index.php?url=/master-data/locations',
    'Salas (com rotas)' => 'index.php?url=/master-data/rooms',
];

echo "<div class='space-y-4'>";
echo "<p class='text-gray-700 mb-4'><strong>Teste os links abaixo:</strong></p>";

foreach ($urls as $label => $url) {
    if ($url === '') {
        echo "<hr class='my-4'>";
        continue;
    }
    
    echo "<div class='flex items-center justify-between p-4 bg-gray-50 rounded-lg'>";
    echo "<span class='font-medium text-gray-700'>{$label}</span>";
    echo "<a href='{$url}' class='px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition' target='_blank'>Testar →</a>";
    echo "</div>";
}

echo "</div>";

echo "<div class='mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg'>";
echo "<h3 class='font-bold text-blue-900 mb-2'>ℹ️ Como Interpretar</h3>";
echo "<ul class='text-sm text-blue-800 space-y-1 ml-4'>";
echo "<li>✅ <strong>Funciona</strong>: Você vê a página correta</li>";
echo "<li>❌ <strong>404</strong>: Rota não configurada (normal por enquanto)</li>";
echo "<li>⚠️ <strong>Redirect</strong>: Precisa fazer login</li>";
echo "</ul>";
echo "</div>";

echo "</div></div>";
echo "</body></html>";
?>
