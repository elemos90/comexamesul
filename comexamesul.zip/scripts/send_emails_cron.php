#!/usr/bin/env php
<?php

/**
 * Wrapper para o cron de envio de emails
 * Redireciona para app/Cron/send_emails.php
 */

require_once __DIR__ . '/../app/Cron/send_emails.php';
