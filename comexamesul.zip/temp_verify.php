<?php
$hash = '$2y$10$mIWRlUQCztZGc8zjOP53D.fuQibiYzLUbaazCz5nwhBL2oWoO4gjm';
var_dump(password_verify('password', $hash));
