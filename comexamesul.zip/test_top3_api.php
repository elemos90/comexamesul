<?php
/**
 * Script de Teste - API Top-3
 * 
 * Execute: http://localhost/test_top3_api.php
 */

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/app/helpers.php';

// Iniciar sessão
session_start();
$_SESSION['user_id'] = 1; // Simular usuário logado

use App\Database\Connection;
use App\Controllers\SuggestController;

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Teste Top-3 API</title>
    <style>
        body { 
            font-family: monospace; 
            padding: 20px; 
            background: #1e1e1e; 
            color: #d4d4d4;
        }
        .success { color: #4ec9b0; }
        .error { color: #f48771; }
        .warning { color: #dcdcaa; }
        .section { 
            background: #252526; 
            padding: 15px; 
            margin: 10px 0; 
            border-left: 3px solid #007acc;
        }
        h2 { color: #569cd6; }
        pre { 
            background: #1e1e1e; 
            padding: 10px; 
            overflow-x: auto;
            border: 1px solid #3e3e3e;
        }
    </style>
</head>
<body>
<h1>🧪 Teste Sistema Top-3</h1>
";

// =========================================
// TESTE 1: Verificar Autoloader
// =========================================
echo "<div class='section'>";
echo "<h2>✓ Teste 1: Verificar Classes</h2>";
try {
    if (class_exists('App\Controllers\SuggestController')) {
        echo "<p class='success'>✓ SuggestController encontrado</p>";
    } else {
        echo "<p class='error'>✗ SuggestController NÃO encontrado</p>";
    }
    
    if (class_exists('App\Database\Connection')) {
        echo "<p class='success'>✓ Connection encontrado</p>";
    } else {
        echo "<p class='error'>✗ Connection NÃO encontrado</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>✗ Erro: " . htmlspecialchars($e->getMessage()) . "</p>";
}
echo "</div>";

// =========================================
// TESTE 2: Verificar Conexão BD
// =========================================
echo "<div class='section'>";
echo "<h2>✓ Teste 2: Conexão com Banco de Dados</h2>";
try {
    $db = Connection::getInstance();
    echo "<p class='success'>✓ Conexão estabelecida</p>";
    
    // Verificar tabelas
    $stmt = $db->query("SHOW TABLES LIKE 'juries'");
    if ($stmt->rowCount() > 0) {
        echo "<p class='success'>✓ Tabela 'juries' existe</p>";
    } else {
        echo "<p class='error'>✗ Tabela 'juries' NÃO existe</p>";
    }
    
    $stmt = $db->query("SHOW TABLES LIKE 'jury_vigilantes'");
    if ($stmt->rowCount() > 0) {
        echo "<p class='success'>✓ Tabela 'jury_vigilantes' existe</p>";
    } else {
        echo "<p class='error'>✗ Tabela 'jury_vigilantes' NÃO existe</p>";
    }
    
    $stmt = $db->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() > 0) {
        echo "<p class='success'>✓ Tabela 'users' existe</p>";
    } else {
        echo "<p class='error'>✗ Tabela 'users' NÃO existe</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>✗ Erro de conexão: " . htmlspecialchars($e->getMessage()) . "</p>";
}
echo "</div>";

// =========================================
// TESTE 3: Verificar Colunas
// =========================================
echo "<div class='section'>";
echo "<h2>✓ Teste 3: Verificar Colunas Necessárias</h2>";
try {
    // Verificar colunas em juries
    $stmt = $db->query("SHOW COLUMNS FROM juries");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $requiredJuriesColumns = ['inicio', 'fim', 'vigilantes_capacidade', 'location'];
    foreach ($requiredJuriesColumns as $col) {
        if (in_array($col, $columns)) {
            echo "<p class='success'>✓ juries.$col existe</p>";
        } else {
            echo "<p class='error'>✗ juries.$col NÃO existe</p>";
        }
    }
    
    // Verificar colunas em jury_vigilantes
    $stmt = $db->query("SHOW COLUMNS FROM jury_vigilantes");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $requiredJVColumns = ['papel', 'juri_inicio', 'juri_fim'];
    foreach ($requiredJVColumns as $col) {
        if (in_array($col, $columns)) {
            echo "<p class='success'>✓ jury_vigilantes.$col existe</p>";
        } else {
            echo "<p class='error'>✗ jury_vigilantes.$col NÃO existe</p>";
        }
    }
    
    // Verificar colunas em users
    $stmt = $db->query("SHOW COLUMNS FROM users");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $requiredUsersColumns = ['campus', 'active', 'available_for_vigilance'];
    foreach ($requiredUsersColumns as $col) {
        if (in_array($col, $columns)) {
            echo "<p class='success'>✓ users.$col existe</p>";
        } else {
            echo "<p class='error'>✗ users.$col NÃO existe</p>";
        }
    }
    
    // Verificar coluna opcional
    if (in_array('experiencia_supervisao', $columns)) {
        echo "<p class='success'>✓ users.experiencia_supervisao existe (OPCIONAL)</p>";
    } else {
        echo "<p class='warning'>⚠ users.experiencia_supervisao NÃO existe (opcional, mas recomendado)</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>✗ Erro: " . htmlspecialchars($e->getMessage()) . "</p>";
}
echo "</div>";

// =========================================
// TESTE 4: Contar Dados
// =========================================
echo "<div class='section'>";
echo "<h2>✓ Teste 4: Dados Disponíveis</h2>";
try {
    // Contar júris
    $stmt = $db->query("SELECT COUNT(*) FROM juries");
    $totalJuries = $stmt->fetchColumn();
    echo "<p>Total de júris: <strong>$totalJuries</strong></p>";
    
    // Contar júris com janelas
    $stmt = $db->query("SELECT COUNT(*) FROM juries WHERE inicio IS NOT NULL AND fim IS NOT NULL");
    $juriesComJanela = $stmt->fetchColumn();
    echo "<p>Júris com janelas temporais: <strong>$juriesComJanela</strong></p>";
    
    // Contar docentes elegíveis
    $stmt = $db->query("SELECT COUNT(*) FROM users WHERE active = 1 AND available_for_vigilance = 1");
    $docentesElegiveis = $stmt->fetchColumn();
    echo "<p>Docentes elegíveis: <strong>$docentesElegiveis</strong></p>";
    
    // Contar alocações
    $stmt = $db->query("SELECT COUNT(*) FROM jury_vigilantes");
    $totalAlocacoes = $stmt->fetchColumn();
    echo "<p>Alocações existentes: <strong>$totalAlocacoes</strong></p>";
    
    // Avisos
    if ($totalJuries == 0) {
        echo "<p class='warning'>⚠ Nenhum júri criado. Crie júris primeiro!</p>";
    }
    if ($juriesComJanela == 0 && $totalJuries > 0) {
        echo "<p class='error'>✗ Júris sem janelas temporais. Execute migrations!</p>";
    }
    if ($docentesElegiveis < 3) {
        echo "<p class='warning'>⚠ Poucos docentes disponíveis (<3). Ative mais docentes!</p>";
        echo "<pre>UPDATE users SET active=1, available_for_vigilance=1 WHERE role IN ('coordenador', 'membro', 'docente');</pre>";
    }
} catch (Exception $e) {
    echo "<p class='error'>✗ Erro: " . htmlspecialchars($e->getMessage()) . "</p>";
}
echo "</div>";

// =========================================
// TESTE 5: Testar API diretamente
// =========================================
echo "<div class='section'>";
echo "<h2>✓ Teste 5: Simular Chamada API</h2>";
try {
    // Buscar primeiro júri disponível
    $stmt = $db->query("SELECT id, subject, location, room, inicio, fim FROM juries WHERE inicio IS NOT NULL LIMIT 1");
    $juri = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($juri) {
        echo "<p class='success'>✓ Júri de teste encontrado: #{$juri['id']} - {$juri['subject']}</p>";
        
        // Simular GET request
        $_GET['juri_id'] = $juri['id'];
        $_GET['papel'] = 'supervisor';
        
        // Capturar output
        ob_start();
        $controller = new SuggestController();
        $controller->top3();
        $output = ob_get_clean();
        
        // Verificar se é JSON válido
        $json = json_decode($output, true);
        
        if (json_last_error() === JSON_ERROR_NONE) {
            echo "<p class='success'>✓ API retornou JSON válido</p>";
            echo "<pre>" . json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
            
            if ($json['ok'] === true) {
                echo "<p class='success'>✓ API funcionou corretamente!</p>";
                echo "<p>Top-3 retornados: <strong>" . count($json['top3']) . "</strong> docentes</p>";
            } else {
                echo "<p class='warning'>⚠ API retornou erro: " . htmlspecialchars($json['error']) . "</p>";
            }
        } else {
            echo "<p class='error'>✗ API NÃO retornou JSON válido</p>";
            echo "<p>Erro: " . json_last_error_msg() . "</p>";
            echo "<pre>" . htmlspecialchars(substr($output, 0, 500)) . "...</pre>";
        }
    } else {
        echo "<p class='warning'>⚠ Nenhum júri encontrado para teste</p>";
        echo "<p>Crie um júri primeiro em: <a href='/juries/planning' style='color: #4ec9b0;'>/juries/planning</a></p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>✗ Erro ao testar API: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
}
echo "</div>";

// =========================================
// DIAGNÓSTICO FINAL
// =========================================
echo "<div class='section'>";
echo "<h2>🎯 Diagnóstico Final</h2>";

$erros = [];
$avisos = [];

if (!class_exists('App\Controllers\SuggestController')) {
    $erros[] = "SuggestController não encontrado. Execute: composer dump-autoload";
}

try {
    $stmt = $db->query("SELECT COUNT(*) FROM juries WHERE inicio IS NULL");
    if ($stmt->fetchColumn() > 0) {
        $erros[] = "Júris sem janelas temporais. Execute migrations_auto_allocation_simple.sql";
    }
} catch (Exception $e) {
    $erros[] = "Erro ao verificar júris: " . $e->getMessage();
}

try {
    $stmt = $db->query("SELECT COUNT(*) FROM users WHERE active=1 AND available_for_vigilance=1");
    if ($stmt->fetchColumn() < 3) {
        $avisos[] = "Poucos docentes disponíveis. Ative mais docentes.";
    }
} catch (Exception $e) {
    $erros[] = "Erro ao verificar docentes: " . $e->getMessage();
}

if (empty($erros) && empty($avisos)) {
    echo "<p class='success' style='font-size: 18px;'>✅ TUDO OK! Sistema Top-3 pronto para uso!</p>";
    echo "<p>Acesse: <a href='/juries/planning' style='color: #4ec9b0; font-weight: bold;'>/juries/planning</a></p>";
    echo "<p>Clique em '⚡ Sugestões Top-3' em qualquer slot vazio</p>";
} else {
    if (!empty($erros)) {
        echo "<h3 style='color: #f48771;'>❌ Erros Encontrados:</h3>";
        echo "<ul>";
        foreach ($erros as $erro) {
            echo "<li class='error'>$erro</li>";
        }
        echo "</ul>";
    }
    
    if (!empty($avisos)) {
        echo "<h3 style='color: #dcdcaa;'>⚠️ Avisos:</h3>";
        echo "<ul>";
        foreach ($avisos as $aviso) {
            echo "<li class='warning'>$aviso</li>";
        }
        echo "</ul>";
    }
}

echo "</div>";

echo "
<div class='section'>
<h2>📚 Links Úteis</h2>
<ul>
    <li><a href='/juries/planning' style='color: #4ec9b0;'>Interface de Planejamento</a></li>
    <li><a href='/phpmyadmin' target='_blank' style='color: #4ec9b0;'>phpMyAdmin</a></li>
    <li><a href='/INSTALACAO_TOP3.md' target='_blank' style='color: #4ec9b0;'>Guia de Instalação</a></li>
    <li><a href='/README_SMART_SUGGESTIONS.md' target='_blank' style='color: #4ec9b0;'>Documentação Completa</a></li>
</ul>
</div>

<p style='text-align: center; color: #666; margin-top: 30px;'>
    Sistema Top-3 - Teste executado em " . date('Y-m-d H:i:s') . "
</p>
</body>
</html>";
