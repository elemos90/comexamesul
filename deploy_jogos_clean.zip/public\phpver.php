<?php echo phpversion();
