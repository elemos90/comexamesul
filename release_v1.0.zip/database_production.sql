-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: comexamesul
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `entity` varchar(120) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `action` varchar(60) NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `ip` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_activity_user` (`user_id`),
  KEY `idx_activity_entity` (`entity`,`entity_id`),
  CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,1,'vacancies',NULL,'create','{\"title\":\"EXAMES 2026\",\"description\":\"Exames de admissao UniLicungo 2026\",\"deadline_at\":\"2026-02-07 19:33:00\",\"status\":\"aberta\",\"created_by\":1,\"created_at\":\"2026-01-31 19:33:41\",\"updated_at\":\"2026-01-31 19:33:41\"}','::1','2026-01-31 19:33:41'),(2,1,'auth',1,'logout','[]','::1','2026-01-31 19:33:53'),(3,3,'auth',3,'login_success','[]','::1','2026-01-31 19:34:00'),(4,3,'auth',3,'logout','[]','::1','2026-01-31 19:36:38'),(5,3,'auth',3,'login_success','[]','::1','2026-01-31 19:36:50'),(6,3,'auth',3,'logout','[]','::1','2026-01-31 19:36:57'),(7,1,'auth',1,'login_success','[]','::1','2026-01-31 19:37:03'),(8,1,'vacancies',1,'delete','{\"title\":\"EXAMES 2026\",\"status\":\"aberta\"}','::1','2026-01-31 19:37:09'),(9,1,'vacancies',NULL,'create','{\"title\":\"EXAMES 2026\",\"description\":\"Exames da Admissao 2026\",\"deadline_at\":\"2026-02-07 19:37:00\",\"status\":\"aberta\",\"created_by\":1,\"created_at\":\"2026-01-31 19:37:29\",\"updated_at\":\"2026-01-31 19:37:29\"}','::1','2026-01-31 19:37:29'),(10,2,'auth',2,'logout','[]','127.0.0.1','2026-01-31 19:37:36'),(11,2,'auth',2,'login_success','[]','127.0.0.1','2026-01-31 19:37:38'),(12,1,'auth',1,'logout','[]','::1','2026-01-31 19:37:54'),(13,3,'auth',3,'login_success','[]','::1','2026-01-31 19:38:00'),(14,3,'auth',3,'logout','[]','::1','2026-01-31 19:40:44'),(15,1,'auth',1,'login_success','[]','::1','2026-01-31 19:40:49'),(16,1,'vacancies',2,'delete','{\"title\":\"EXAMES 2026\",\"status\":\"aberta\"}','::1','2026-01-31 19:53:06'),(17,1,'vacancies',NULL,'create','{\"title\":\"exames 2026\",\"description\":\"exames unilcungo\",\"deadline_at\":\"2026-02-07 19:53:00\",\"status\":\"aberta\",\"created_by\":1,\"created_at\":\"2026-01-31 19:53:26\",\"updated_at\":\"2026-01-31 19:53:26\"}','::1','2026-01-31 19:53:26'),(18,1,'auth',1,'logout','[]','::1','2026-01-31 20:33:49'),(19,3,'auth',3,'login_success','[]','::1','2026-01-31 20:33:56'),(20,3,'vacancy_applications',3,'apply','{\"vacancy_id\":3,\"vigilante_id\":3}','::1','2026-01-31 20:34:02'),(21,3,'auth',3,'logout','[]','::1','2026-01-31 20:34:23'),(22,4,'auth',4,'login_success','[]','::1','2026-01-31 20:34:34'),(23,4,'vacancy_applications',3,'apply','{\"vacancy_id\":3,\"vigilante_id\":4}','::1','2026-01-31 20:34:41'),(24,4,'auth',4,'logout','[]','::1','2026-01-31 20:35:20'),(25,5,'auth',5,'login_success','[]','::1','2026-01-31 20:35:25'),(26,5,'vacancy_applications',3,'apply','{\"vacancy_id\":3,\"vigilante_id\":5}','::1','2026-01-31 20:35:30'),(27,5,'auth',5,'logout','[]','::1','2026-01-31 20:35:35'),(28,6,'auth',6,'login_success','[]','::1','2026-01-31 20:35:40'),(29,6,'vacancy_applications',3,'apply','{\"vacancy_id\":3,\"vigilante_id\":6}','::1','2026-01-31 20:35:45'),(30,6,'auth',6,'logout','[]','::1','2026-01-31 20:35:50'),(31,7,'auth',7,'login_success','[]','::1','2026-01-31 20:35:56'),(32,7,'vacancy_applications',3,'apply','{\"vacancy_id\":3,\"vigilante_id\":7}','::1','2026-01-31 20:36:00'),(33,7,'auth',7,'logout','[]','::1','2026-01-31 20:36:05'),(34,8,'auth',8,'login_success','[]','::1','2026-01-31 20:36:12'),(35,8,'vacancy_applications',3,'apply','{\"vacancy_id\":3,\"vigilante_id\":8}','::1','2026-01-31 20:36:16'),(36,8,'auth',8,'logout','[]','::1','2026-01-31 20:36:20'),(37,9,'auth',9,'login_success','[]','::1','2026-01-31 20:36:28'),(38,9,'vacancy_applications',3,'apply','{\"vacancy_id\":3,\"vigilante_id\":9}','::1','2026-01-31 20:36:32'),(39,9,'auth',9,'logout','[]','::1','2026-01-31 20:36:38'),(40,10,'auth',10,'login_success','[]','::1','2026-01-31 20:36:43'),(41,10,'vacancy_applications',3,'apply','{\"vacancy_id\":3,\"vigilante_id\":10}','::1','2026-01-31 20:36:47'),(42,10,'auth',10,'logout','[]','::1','2026-01-31 20:36:52'),(43,11,'auth',11,'login_success','[]','::1','2026-01-31 20:37:05'),(44,11,'auth',11,'logout','[]','::1','2026-01-31 20:37:10'),(45,1,'auth',1,'login_success','[]','::1','2026-01-31 20:37:16'),(46,1,'vacancy_applications',8,'approve','{\"vacancy_id\":3,\"vigilante_id\":10}','::1','2026-01-31 20:38:41'),(47,1,'vacancy_applications',7,'approve','{\"vacancy_id\":3,\"vigilante_id\":9}','::1','2026-01-31 20:38:45'),(48,1,'vacancy_applications',6,'approve','{\"vacancy_id\":3,\"vigilante_id\":8}','::1','2026-01-31 20:38:49'),(49,1,'vacancy_applications',5,'approve','{\"vacancy_id\":3,\"vigilante_id\":7}','::1','2026-01-31 20:38:54'),(50,1,'vacancy_applications',4,'approve','{\"vacancy_id\":3,\"vigilante_id\":6}','::1','2026-01-31 20:38:58'),(51,1,'vacancy_applications',3,'approve','{\"vacancy_id\":3,\"vigilante_id\":5}','::1','2026-01-31 20:39:02'),(52,1,'vacancy_applications',2,'approve','{\"vacancy_id\":3,\"vigilante_id\":4}','::1','2026-01-31 20:39:06'),(53,1,'vacancy_applications',1,'approve','{\"vacancy_id\":3,\"vigilante_id\":3}','::1','2026-01-31 20:39:10'),(54,1,'jury_vigilantes',1,'assign_from_wizard','{\"vigilante_id\":9}','::1','2026-01-31 20:40:05'),(55,1,'juries',1,'create_for_vacancy','{\"vacancy_id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S1\"}','::1','2026-01-31 20:40:05'),(56,1,'juries',1,'assign_supervisor','{\"supervisor_id\":11,\"context\":\"block_wizard\",\"assigned_by\":1}','::1','2026-01-31 20:40:05'),(57,1,'jury_vigilantes',2,'assign_from_wizard','{\"vigilante_id\":10}','::1','2026-01-31 20:42:01'),(58,1,'juries',2,'create_for_vacancy','{\"vacancy_id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S2\"}','::1','2026-01-31 20:42:01'),(59,1,'jury_vigilantes',3,'assign_from_wizard','{\"vigilante_id\":3}','::1','2026-01-31 20:42:01'),(60,1,'jury_vigilantes',3,'assign_from_wizard','{\"vigilante_id\":4}','::1','2026-01-31 20:42:01'),(61,1,'juries',3,'create_for_vacancy','{\"vacancy_id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S3\"}','::1','2026-01-31 20:42:01'),(62,1,'juries',2,'assign_supervisor','{\"supervisor_id\":11,\"context\":\"block_wizard\",\"assigned_by\":1}','::1','2026-01-31 20:42:01'),(63,1,'juries',3,'assign_supervisor','{\"supervisor_id\":11,\"context\":\"block_wizard\",\"assigned_by\":1}','::1','2026-01-31 20:42:01'),(64,1,'juries',3,'delete','{\"deleted_by\":1,\"jury_data\":{\"id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S3\",\"exam_date\":\"2026-02-01\",\"vacancy_id\":3},\"timestamp\":\"2026-01-31 20:46:45\"}','::1','2026-01-31 20:46:45'),(65,1,'juries',2,'delete','{\"deleted_by\":1,\"jury_data\":{\"id\":2,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S2\",\"exam_date\":\"2026-02-01\",\"vacancy_id\":3},\"timestamp\":\"2026-01-31 20:46:50\"}','::1','2026-01-31 20:46:50'),(66,1,'juries',1,'delete','{\"deleted_by\":1,\"jury_data\":{\"id\":1,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S1\",\"exam_date\":\"2026-02-01\",\"vacancy_id\":3},\"timestamp\":\"2026-01-31 20:46:55\"}','::1','2026-01-31 20:46:55'),(67,1,'jury_vigilantes',4,'assign_from_wizard','{\"vigilante_id\":9}','::1','2026-01-31 21:10:16'),(68,1,'juries',4,'create_for_vacancy','{\"vacancy_id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S1\"}','::1','2026-01-31 21:10:16'),(69,1,'juries',4,'assign_supervisor','{\"supervisor_id\":7,\"context\":\"block_wizard\",\"assigned_by\":1}','::1','2026-01-31 21:10:16'),(70,1,'jury_vigilantes',5,'assign_from_wizard','{\"vigilante_id\":10}','::1','2026-01-31 21:12:11'),(71,1,'juries',5,'create_for_vacancy','{\"vacancy_id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S2\"}','::1','2026-01-31 21:12:11'),(72,1,'jury_vigilantes',6,'assign_from_wizard','{\"vigilante_id\":3}','::1','2026-01-31 21:12:11'),(73,1,'juries',6,'create_for_vacancy','{\"vacancy_id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S3\"}','::1','2026-01-31 21:12:11'),(74,1,'juries',5,'assign_supervisor','{\"supervisor_id\":7,\"context\":\"block_wizard\",\"assigned_by\":1}','::1','2026-01-31 21:12:11'),(75,1,'juries',6,'assign_supervisor','{\"supervisor_id\":7,\"context\":\"block_wizard\",\"assigned_by\":1}','::1','2026-01-31 21:12:11'),(76,1,'juries',5,'delete','{\"deleted_by\":1,\"jury_data\":{\"id\":5,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S2\",\"exam_date\":\"2026-02-01\",\"vacancy_id\":3},\"timestamp\":\"2026-01-31 21:12:38\"}','::1','2026-01-31 21:12:38'),(77,1,'juries',6,'delete','{\"deleted_by\":1,\"jury_data\":{\"id\":6,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S3\",\"exam_date\":\"2026-02-01\",\"vacancy_id\":3},\"timestamp\":\"2026-01-31 21:12:44\"}','::1','2026-01-31 21:12:44'),(78,1,'jury_vigilantes',7,'assign_from_wizard','{\"vigilante_id\":10}','::1','2026-01-31 21:13:45'),(79,1,'juries',7,'create_for_vacancy','{\"vacancy_id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S2\"}','::1','2026-01-31 21:13:45'),(80,1,'jury_vigilantes',8,'assign_from_wizard','{\"vigilante_id\":3}','::1','2026-01-31 21:13:45'),(81,1,'juries',8,'create_for_vacancy','{\"vacancy_id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S3\"}','::1','2026-01-31 21:13:45'),(82,1,'juries',7,'assign_supervisor','{\"supervisor_id\":12,\"context\":\"block_wizard\",\"assigned_by\":1}','::1','2026-01-31 21:13:45'),(83,1,'juries',8,'assign_supervisor','{\"supervisor_id\":12,\"context\":\"block_wizard\",\"assigned_by\":1}','::1','2026-01-31 21:13:45'),(84,1,'juries',4,'delete','{\"deleted_by\":1,\"jury_data\":{\"id\":4,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S1\",\"exam_date\":\"2026-02-01\",\"vacancy_id\":3},\"timestamp\":\"2026-01-31 21:20:27\"}','::1','2026-01-31 21:20:27'),(85,1,'jury_vigilantes',9,'assign_from_wizard','{\"vigilante_id\":9}','::1','2026-01-31 21:21:06'),(86,1,'jury_vigilantes',9,'assign_from_wizard','{\"vigilante_id\":4}','::1','2026-01-31 21:21:06'),(87,1,'juries',9,'create_for_vacancy','{\"vacancy_id\":3,\"subject\":\"Qu\\u00edmica I\",\"room\":\"S1\"}','::1','2026-01-31 21:21:06'),(88,1,'juries',9,'assign_supervisor','{\"supervisor_id\":8,\"context\":\"block_wizard\",\"assigned_by\":1}','::1','2026-01-31 21:21:06'),(89,1,'vacancies',3,'validate_planning','{\"total_juries\":3,\"total_candidates\":\"67\"}','::1','2026-01-31 21:25:40'),(90,1,'auth',1,'login_success','[]','127.0.0.1','2026-02-18 14:05:56'),(91,3,'auth',3,'login_success','[]','192.168.1.119','2026-02-18 14:11:33'),(92,1,'vacancies',3,'update','[]','127.0.0.1','2026-02-18 14:14:25'),(93,1,'vacancies',3,'update','[]','127.0.0.1','2026-02-18 14:15:10'),(94,3,'auth',3,'logout','[]','192.168.1.119','2026-02-18 14:16:30'),(95,1,'auth',1,'login_success','[]','192.168.1.119','2026-02-18 14:16:50'),(96,1,'vacancies',3,'update','[]','127.0.0.1','2026-02-18 14:18:21'),(97,1,'vacancies',3,'update','[]','127.0.0.1','2026-02-18 14:19:06'),(98,1,'vacancies',3,'update','[]','127.0.0.1','2026-02-18 14:19:11'),(99,1,'auth',1,'logout','[]','192.168.1.119','2026-02-18 14:38:41'),(100,2,'auth',2,'login_success','[]','192.168.1.119','2026-02-18 14:39:18'),(101,2,'auth',2,'logout','[]','192.168.1.119','2026-02-18 14:40:59'),(102,1,'auth',1,'login_success','[]','192.168.1.175','2026-02-18 14:50:31'),(103,1,'vacancies',3,'close','[]','192.168.1.175','2026-02-18 14:51:14'),(104,1,'vacancies',NULL,'create','{\"title\":\"Exames de Admissao 2027\",\"description\":\"Ensaio para Exames\",\"deadline_at\":\"2026-02-26 14:51:00\",\"status\":\"aberta\",\"created_by\":1,\"created_at\":\"2026-02-18 14:52:03\",\"updated_at\":\"2026-02-18 14:52:03\"}','192.168.1.175','2026-02-18 14:52:03'),(105,3,'auth',3,'login_success','[]','192.168.1.175','2026-02-18 14:53:42'),(106,NULL,'users',21,'register_self','[]','192.168.1.175','2026-02-18 14:59:07'),(107,21,'auth',21,'login_success','[]','192.168.1.175','2026-02-18 14:59:24'),(108,2,'auth',2,'login_success','[]','192.168.1.238','2026-02-18 14:59:52'),(109,1,'auth',1,'login_success','[]','192.168.1.110','2026-02-18 15:00:01'),(110,2,'auth',2,'login_success','[]','192.168.1.178','2026-02-18 15:02:26'),(111,21,'users',21,'profile_completed','{\"name\":\"Helenio da Silva Joaquim\",\"phone\":\"+258 878287751\",\"gender\":\"M\",\"birth_date\":\"1993-08-04\",\"document_type\":\"BI\",\"document_number\":\"1234567890N\",\"origin_university\":\"Universidade Licungo (UniLicungo)\",\"university\":\"Universidade Licungo\",\"nuit\":\"198280249\",\"degree\":\"Licenciado\",\"major_area\":\"Educacao\",\"bank_name\":\"Millennium BIM\",\"nib\":\"01000000247124379570000\",\"bank_account_holder\":\"Helenio da Silva Joaquim\"}','192.168.1.175','2026-02-18 15:03:31'),(112,21,'auth',21,'login_success','[]','192.168.1.175','2026-02-18 15:03:41'),(113,21,'vacancy_applications',4,'apply','{\"vacancy_id\":4,\"vigilante_id\":21}','192.168.1.175','2026-02-18 15:04:03'),(114,2,'auth',2,'logout','[]','192.168.1.238','2026-02-18 15:05:57'),(115,NULL,'users',22,'register_self','[]','192.168.1.188','2026-02-18 15:06:42'),(116,22,'auth',22,'login_success','[]','192.168.1.188','2026-02-18 15:07:15'),(117,1,'vacancy_applications',9,'approve','{\"vacancy_id\":4,\"vigilante_id\":21}','192.168.1.175','2026-02-18 15:14:16'),(118,1,'users',21,'toggle_supervisor_eligible','{\"supervisor_eligible\":true,\"application_id\":9,\"vacancy_id\":4,\"updated_by\":1}','192.168.1.175','2026-02-18 15:17:57'),(119,1,'users',21,'toggle_supervisor_eligible','{\"supervisor_eligible\":false,\"application_id\":9,\"vacancy_id\":4,\"updated_by\":1}','192.168.1.175','2026-02-18 15:18:47'),(120,1,'jury_vigilantes',10,'assign_from_wizard','{\"vigilante_id\":21}','192.168.1.175','2026-02-18 15:52:28'),(121,1,'juries',10,'create_for_vacancy','{\"vacancy_id\":4,\"subject\":\"Biologia I\",\"room\":\"101\"}','192.168.1.175','2026-02-18 15:52:28'),(122,1,'juries',10,'assign_supervisor','{\"supervisor_id\":22,\"context\":\"block_wizard\",\"assigned_by\":1}','192.168.1.175','2026-02-18 15:52:28'),(123,1,'vacancies',3,'finalize','{\"title\":\"exames 2026\",\"previous_status\":\"fechada\"}','127.0.0.1','2026-02-18 15:53:31'),(124,1,'juries',10,'update_discipline','{\"subject\":\"Biologia I\",\"vacancy_id\":4}','192.168.1.175','2026-02-18 15:54:19'),(125,1,'vacancies',4,'validate_planning','{\"total_juries\":1,\"total_candidates\":\"30\"}','192.168.1.175','2026-02-18 15:58:09'),(126,21,'exam_reports',10,'create','[]','192.168.1.175','2026-02-18 16:02:57'),(127,1,'auth',1,'login_success','[]','127.0.0.1','2026-02-19 11:14:42'),(128,1,'auth',1,'logout','[]','127.0.0.1','2026-02-19 11:19:32'),(129,1,'auth',1,'login_success','[]','127.0.0.1','2026-02-19 11:19:38'),(130,3,'auth',3,'login_success','[]','127.0.0.1','2026-02-19 11:25:46');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_status_history`
--

DROP TABLE IF EXISTS `application_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_status_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_id` int(11) NOT NULL,
  `old_status` enum('pendente','aprovada','rejeitada','cancelada') DEFAULT NULL,
  `new_status` enum('pendente','aprovada','rejeitada','cancelada') NOT NULL,
  `changed_by` int(11) DEFAULT NULL,
  `changed_at` datetime NOT NULL,
  `reason` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  PRIMARY KEY (`id`),
  KEY `idx_application` (`application_id`),
  KEY `idx_date` (`changed_at`),
  KEY `idx_changed_by` (`changed_by`),
  CONSTRAINT `application_status_history_ibfk_1` FOREIGN KEY (`application_id`) REFERENCES `vacancy_applications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `application_status_history_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_status_history`
--

LOCK TABLES `application_status_history` WRITE;
/*!40000 ALTER TABLE `application_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `availability_change_requests`
--

DROP TABLE IF EXISTS `availability_change_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `availability_change_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vigilante_id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `request_type` enum('cancelamento','alteracao') NOT NULL DEFAULT 'cancelamento',
  `reason` text NOT NULL,
  `attachment_path` varchar(255) DEFAULT NULL,
  `attachment_original_name` varchar(255) DEFAULT NULL,
  `has_allocation` tinyint(1) NOT NULL DEFAULT 0,
  `jury_details` text DEFAULT NULL,
  `status` enum('pendente','aprovada','rejeitada') NOT NULL DEFAULT 'pendente',
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewer_notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_acr_application` (`application_id`),
  KEY `fk_acr_reviewed_by` (`reviewed_by`),
  KEY `idx_acr_status` (`status`),
  KEY `idx_acr_vigilante` (`vigilante_id`),
  CONSTRAINT `fk_acr_application` FOREIGN KEY (`application_id`) REFERENCES `vacancy_applications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_acr_reviewed_by` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_acr_vigilante` FOREIGN KEY (`vigilante_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `availability_change_requests`
--

LOCK TABLES `availability_change_requests` WRITE;
/*!40000 ALTER TABLE `availability_change_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `availability_change_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disciplines`
--

DROP TABLE IF EXISTS `disciplines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disciplines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_disciplines_created_by` (`created_by`),
  KEY `idx_disciplines_active` (`active`),
  KEY `idx_disciplines_code` (`code`),
  CONSTRAINT `fk_disciplines_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disciplines`
--

LOCK TABLES `disciplines` WRITE;
/*!40000 ALTER TABLE `disciplines` DISABLE KEYS */;
INSERT INTO `disciplines` VALUES (1,'MAT1','Matemática I','Matemática básica e introdução ao cálculo',1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(3,'FIS1','Física I','Mecânica clássica e introdução à física',1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(4,'QUI1','Química I','Química geral e inorgânica',1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(5,'BIO1','Biologia I','Biologia celular e molecular',1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(6,'POR1','Português I','Gramática e interpretação de texto',1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(7,'ING1','Inglês I','Inglês básico e comunicação',1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(8,'HIS1','História I','História de Moçambique',1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(9,'GEO1','Geografia I','Geografia física e humana',1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(10,'INF1','Informática I','Introdução à informática',1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29');
/*!40000 ALTER TABLE `disciplines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_notifications`
--

DROP TABLE IF EXISTS `email_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `status` enum('pending','sent','failed') DEFAULT 'pending',
  `sent_at` datetime DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `retry_count` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `email_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_notifications`
--

LOCK TABLES `email_notifications` WRITE;
/*!40000 ALTER TABLE `email_notifications` DISABLE KEYS */;
INSERT INTO `email_notifications` VALUES (1,1,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(2,2,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(3,3,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(4,4,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(5,5,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(6,6,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(7,7,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(8,8,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(9,9,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(10,10,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(11,11,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(12,12,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(13,13,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(14,14,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(15,15,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(16,16,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(17,17,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(18,18,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(19,19,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(20,20,'vacancy_alert','Nova Vaga Disponível: exames 2026','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: exames 2026\n📅 Prazo: 07/02/2026 19:53\n\nAcesse o portal para se candidatar: /comexamesul/public/vacancies/3','pending',NULL,NULL,0,'2026-01-31 19:53:26'),(21,1,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(22,2,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(23,3,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(24,4,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(25,5,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(26,6,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(27,7,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(28,8,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(29,9,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(30,10,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(31,11,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(32,12,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(33,13,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(34,14,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(35,15,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(36,16,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(37,17,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(38,18,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(39,19,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03'),(40,20,'vacancy_alert','Nova Vaga Disponível: Exames de Admissao 2027','Olá,\n\nUma nova oportunidade de vigilância foi publicada no portal:\n\n📌 Título: Exames de Admissao 2027\n📅 Prazo: 26/02/2026 14:51\n\nAcesse o portal para se candidatar: /vacancies/4','pending',NULL,NULL,0,'2026-02-18 14:52:03');
/*!40000 ALTER TABLE `email_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_locations`
--

DROP TABLE IF EXISTS `exam_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_locations_created_by` (`created_by`),
  KEY `idx_locations_active` (`active`),
  KEY `idx_locations_code` (`code`),
  CONSTRAINT `fk_locations_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_locations`
--

LOCK TABLES `exam_locations` WRITE;
/*!40000 ALTER TABLE `exam_locations` DISABLE KEYS */;
INSERT INTO `exam_locations` VALUES (1,'CC','Campus Central','Av. Principal, s/n','Beira',500,NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(2,'ES1','Escola Secundária Samora Machel','Rua da Educação, 123','Beira',300,NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(3,'ES2','Escola Secundária Eduardo Mondlane','Av. Julius Nyerere, 456','Beira',250,'',1,NULL,'2025-10-11 12:12:29','2025-10-11 21:33:55'),(4,'CB','Campus Bairro','Bairro Central, Lote 10','Beira',200,NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29');
/*!40000 ALTER TABLE `exam_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_reports`
--

DROP TABLE IF EXISTS `exam_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jury_id` int(11) NOT NULL,
  `supervisor_id` int(11) NOT NULL,
  `role` varchar(50) DEFAULT 'supervisor',
  `present_m` int(11) NOT NULL DEFAULT 0,
  `present_f` int(11) NOT NULL DEFAULT 0,
  `absent_m` int(11) NOT NULL DEFAULT 0,
  `absent_f` int(11) NOT NULL DEFAULT 0,
  `fraudes_m` int(11) DEFAULT 0,
  `fraudes_f` int(11) DEFAULT 0,
  `total` int(11) NOT NULL DEFAULT 0,
  `occurrences` text DEFAULT NULL,
  `submitted_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_exam_reports_jury` (`jury_id`),
  KEY `fk_reports_supervisor` (`supervisor_id`),
  CONSTRAINT `fk_reports_jury` FOREIGN KEY (`jury_id`) REFERENCES `juries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reports_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_reports`
--

LOCK TABLES `exam_reports` WRITE;
/*!40000 ALTER TABLE `exam_reports` DISABLE KEYS */;
INSERT INTO `exam_reports` VALUES (1,10,21,'vigilante',5,21,1,3,0,0,30,'','2026-02-18 16:02:56','2026-02-18 16:02:56','2026-02-18 16:02:56');
/*!40000 ALTER TABLE `exam_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_rooms`
--

DROP TABLE IF EXISTS `exam_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location_id` int(11) NOT NULL,
  `code` varchar(20) NOT NULL,
  `name` varchar(60) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 30,
  `floor` varchar(20) DEFAULT NULL,
  `building` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_room_location_code` (`location_id`,`code`),
  KEY `fk_rooms_created_by` (`created_by`),
  KEY `idx_rooms_active` (`active`),
  KEY `idx_rooms_location` (`location_id`,`active`),
  CONSTRAINT `fk_rooms_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rooms_location` FOREIGN KEY (`location_id`) REFERENCES `exam_locations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_rooms`
--

LOCK TABLES `exam_rooms` WRITE;
/*!40000 ALTER TABLE `exam_rooms` DISABLE KEYS */;
INSERT INTO `exam_rooms` VALUES (1,1,'101','Sala 101',35,'Piso 1','Bloco A',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(2,1,'102','Sala 102',40,'Piso 1','Bloco A',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(3,1,'103','Sala 103',30,'Piso 1','Bloco A',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(4,1,'201','Sala 201',35,'Piso 2','Bloco A',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(5,1,'202','Sala 202',40,'Piso 2','Bloco A',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(6,1,'AUD1','Auditório Principal',100,'Piso Térreo','Bloco B',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(7,1,'LAB1','Laboratório de Informática',25,'Piso 1','Bloco C',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(8,2,'A1','Sala A1',30,'Piso 1','Edifício Principal',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(9,2,'A2','Sala A2',30,'Piso 1','Edifício Principal',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(10,2,'A3','Sala A3',35,'Piso 1','Edifício Principal',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(11,2,'B1','Sala B1',30,'Piso 2','Edifício Principal',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(12,2,'B2','Sala B2',30,'Piso 2','Edifício Principal',NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(15,3,'1A','Sala 1A',28,'Piso 1',NULL,NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(16,3,'1B','Sala 1B',28,'Piso 1',NULL,NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(17,3,'2A','Sala 2A',32,'Piso 2',NULL,NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(18,3,'2B','Sala 2B',32,'Piso 2',NULL,NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(22,4,'S1','Sala 1',25,'Térreo',NULL,NULL,1,NULL,'2025-10-11 12:12:29','2025-10-11 12:12:29'),(23,4,'S2','Sala 222',25,'Térreo','','COM ACESSO A DIFICIENTES',1,NULL,'2025-10-11 12:12:29','2025-10-13 23:03:20'),(24,4,'S3','Sala 3',10,'Térreo','','',1,NULL,'2025-10-11 12:12:29','2025-10-13 23:24:30'),(25,2,'B3','Sala B3',30,'res de chao','Ginasio','proximo ao portao...',1,1,'2025-10-12 00:03:52','2025-10-12 00:03:52');
/*!40000 ALTER TABLE `exam_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_vacancies`
--

DROP TABLE IF EXISTS `exam_vacancies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_vacancies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(180) NOT NULL,
  `description` text NOT NULL,
  `deadline_at` datetime NOT NULL,
  `status` enum('aberta','fechada','encerrada') NOT NULL DEFAULT 'aberta',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vacancies_created_by` (`created_by`),
  KEY `idx_vacancies_deadline` (`deadline_at`),
  KEY `idx_vacancies_status` (`status`),
  CONSTRAINT `fk_vacancies_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_vacancies`
--

LOCK TABLES `exam_vacancies` WRITE;
/*!40000 ALTER TABLE `exam_vacancies` DISABLE KEYS */;
INSERT INTO `exam_vacancies` VALUES (3,'exames 2026','exames unilcungo','2026-02-18 15:53:00','encerrada',1,'2026-01-31 19:53:26','2026-02-18 15:53:31'),(4,'Exames de Admissao 2027','Ensaio para Exames','2026-02-26 14:51:00','aberta',1,'2026-02-18 14:52:03','2026-02-18 14:52:03');
/*!40000 ALTER TABLE `exam_vacancies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feature_flags`
--

DROP TABLE IF EXISTS `feature_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feature_flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(20) NOT NULL COMMENT 'membro, vigilante',
  `feature_code` varchar(50) NOT NULL COMMENT 'C├│digo ├║nico da funcionalidade',
  `feature_name` varchar(100) NOT NULL COMMENT 'Nome leg├¡vel da funcionalidade',
  `feature_description` varchar(255) DEFAULT NULL COMMENT 'Descri├º├úo para o admin',
  `feature_group` varchar(50) DEFAULT 'geral' COMMENT 'Agrupamento no UI',
  `enabled` tinyint(1) DEFAULT 1 COMMENT '1=ativo, 0=desativado',
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_feature` (`role`,`feature_code`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_role` (`role`),
  KEY `idx_feature_code` (`feature_code`),
  CONSTRAINT `feature_flags_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature_flags`
--

LOCK TABLES `feature_flags` WRITE;
/*!40000 ALTER TABLE `feature_flags` DISABLE KEYS */;
INSERT INTO `feature_flags` VALUES (1,'membro','commission.create_jury','Criar Júris','Permite criar novos júris para vagas','juris',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(2,'membro','commission.edit_jury','Editar Júris','Permite modificar júris existentes','juris',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(3,'membro','commission.delete_jury','Eliminar Júris','Permite eliminar júris','juris',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(4,'membro','commission.auto_vigilantes','Auto-distribuir Vigilantes','Distribuição automática de vigilantes','alocacao',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(5,'membro','commission.auto_supervisors','Auto-distribuir Supervisores','Distribuição automática de supervisores','alocacao',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(6,'membro','commission.manual_allocation','Alocação Manual','Alocar vigilantes/supervisores manualmente','alocacao',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(7,'membro','commission.post_exam','Submeter Relatório Pós-Exame','Submeter relatórios após exames','relatorios',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(8,'membro','commission.view_payments','Ver Mapa de Pagamentos','Acesso ao mapa geral de pagamentos','pagamentos',1,NULL,'2026-01-08 12:26:02','2026-01-08 12:26:02'),(9,'membro','commission.export_reports','Exportar Relatórios','Exportar dados em PDF/Excel','exportacao',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(10,'vigilante','guard.view_juries','Ver Júris Alocados','Ver os júris onde está alocado','visualizacao',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(11,'vigilante','guard.view_calendar','Ver Calendário','Acesso ao calendário de exames','visualizacao',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(12,'vigilante','guard.post_exam','Submeter Relatório Pós-Exame','Submeter relatórios após exames','relatorios',1,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(13,'vigilante','guard.edit_post_exam','Editar Relatório','Editar relatório antes da validação','relatorios',0,NULL,'2026-01-08 14:09:40','2026-01-08 12:26:02'),(14,'vigilante','guard.view_own_payment','Ver Meu Pagamento','Ver mapa individual de pagamento','pagamentos',1,NULL,'2026-01-08 12:26:02','2026-01-08 12:26:02'),(15,'vigilante','guard.export_payment_pdf','Exportar PDF de Pagamento','Exportar comprovativo individual','pagamentos',0,1,'2026-01-20 14:11:05','2026-01-08 12:26:02'),(16,'supervisor','supervisor.view_juries','Ver júris supervisionados','Ver os júris sob sua supervisão','visualizacao',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15'),(17,'supervisor','supervisor.consolidate_reports','Consolidar relatórios','Consolidar relatórios de júris','relatorios',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15'),(18,'supervisor','supervisor.validate_reports','Validar relatórios','Validar relatórios de vigilantes','relatorios',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15'),(19,'supervisor','supervisor.submit_block_notes','Observação do bloco','Submeter observação global do bloco','relatorios',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15'),(20,'supervisor','supervisor.view_block_summary','Resumo do bloco','Ver resumo do bloco supervisionado','visualizacao',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15'),(21,'supervisor','guard.view_juries','Ver júris alocados','Ver os júris onde está alocado','visualizacao',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15'),(22,'supervisor','guard.post_exam','Submeter relatório pós-exame','Submeter relatórios após exames','relatorios',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15'),(23,'supervisor','guard.edit_post_exam','Editar relatório','Editar relatório antes da validação','relatorios',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15'),(24,'supervisor','guard.view_own_payment','Ver meu pagamento','Ver mapa individual de pagamento','pagamentos',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15'),(25,'supervisor','guard.export_payment_pdf','Exportar PDF de pagamento','Exportar comprovativo individual','exportacao',1,1,'2026-01-08 15:29:15','2026-01-08 15:29:15');
/*!40000 ALTER TABLE `feature_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `juries`
--

DROP TABLE IF EXISTS `juries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `juries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vacancy_id` int(11) DEFAULT NULL,
  `subject` varchar(180) NOT NULL,
  `exam_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `location` varchar(150) NOT NULL,
  `room` varchar(60) NOT NULL,
  `candidates_quota` int(11) NOT NULL,
  `vigilantes_capacity` int(11) DEFAULT 2,
  `requires_supervisor` tinyint(1) DEFAULT 1,
  `notes` text DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `inicio` datetime DEFAULT NULL COMMENT 'Data/hora in├¡cio do j├║ri (formato YYYY-MM-DD HH:MM:SS)',
  `fim` datetime DEFAULT NULL COMMENT 'Data/hora fim do j├║ri',
  `vigilantes_capacidade` int(11) NOT NULL DEFAULT 2 COMMENT 'Capacidade m├íxima de vigilantes',
  `discipline_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_juries_approved_by` (`approved_by`),
  KEY `fk_juries_created_by` (`created_by`),
  KEY `idx_juries_schedule` (`exam_date`,`start_time`,`end_time`),
  KEY `idx_juries_datetime` (`exam_date`,`start_time`,`end_time`),
  KEY `idx_juries_supervisor` (`supervisor_id`),
  KEY `idx_juries_local_date` (`location`,`exam_date`),
  KEY `idx_juries_intervalo` (`inicio`,`fim`),
  KEY `fk_juries_discipline` (`discipline_id`),
  KEY `fk_juries_room` (`room_id`),
  KEY `idx_juries_vacancy` (`vacancy_id`),
  KEY `idx_juries_location_date` (`location_id`,`exam_date`,`start_time`),
  KEY `idx_juries_subject` (`subject`,`exam_date`),
  CONSTRAINT `fk_juries_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_juries_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_juries_discipline` FOREIGN KEY (`discipline_id`) REFERENCES `disciplines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_juries_location` FOREIGN KEY (`location_id`) REFERENCES `exam_locations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_juries_room` FOREIGN KEY (`room_id`) REFERENCES `exam_rooms` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_juries_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_juries_vacancy` FOREIGN KEY (`vacancy_id`) REFERENCES `exam_vacancies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `juries`
--

LOCK TABLES `juries` WRITE;
/*!40000 ALTER TABLE `juries` DISABLE KEYS */;
INSERT INTO `juries` VALUES (7,3,'Química I','2026-02-01','08:00:00','10:00:00','Campus Bairro','S2',25,2,1,NULL,12,NULL,1,'2026-01-31 21:13:45','2026-01-31 21:13:45',NULL,NULL,2,NULL,NULL,NULL),(8,3,'Química I','2026-02-01','08:00:00','10:00:00','Campus Bairro','S3',10,2,1,NULL,12,NULL,1,'2026-01-31 21:13:45','2026-01-31 21:13:45',NULL,NULL,2,NULL,NULL,NULL),(9,3,'Química I','2026-02-01','08:00:00','10:00:00','Campus Bairro','S1',32,2,1,NULL,8,NULL,1,'2026-01-31 21:21:06','2026-01-31 21:21:06',NULL,NULL,2,NULL,NULL,NULL),(10,4,'Biologia I','2027-02-19','20:00:00','22:00:00','Campus Central','101',30,2,1,NULL,22,NULL,1,'2026-02-18 15:52:28','2026-02-18 15:54:19',NULL,NULL,2,NULL,1,NULL);
/*!40000 ALTER TABLE `juries` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017*/ /*!50003 TRIGGER trg_check_supervisor_conflicts
BEFORE UPDATE ON juries
FOR EACH ROW
BEGIN
    DECLARE v_conflict_count INT;
    
    
    IF NEW.supervisor_id IS NOT NULL AND (OLD.supervisor_id IS NULL OR OLD.supervisor_id != NEW.supervisor_id) THEN
        
        
        
        SELECT COUNT(*)
        INTO v_conflict_count
        FROM juries j
        WHERE j.supervisor_id = NEW.supervisor_id
          AND j.exam_date = NEW.exam_date
          AND j.id != NEW.id
          
          AND NOT (
              j.subject = NEW.subject 
              AND j.start_time = NEW.start_time 
              AND j.end_time = NEW.end_time
          )
          AND (
              
              (j.start_time < NEW.end_time) AND (NEW.start_time < j.end_time)
          );
        
        IF v_conflict_count > 0 THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Supervisor j?? est?? alocado em j??ri com hor??rio conflitante no mesmo dia';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `jury_vigilantes`
--

DROP TABLE IF EXISTS `jury_vigilantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jury_vigilantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jury_id` int(11) NOT NULL,
  `vigilante_id` int(11) NOT NULL,
  `jury_exam_date` date DEFAULT NULL,
  `jury_start_time` time DEFAULT NULL,
  `jury_end_time` time DEFAULT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `papel` enum('vigilante','supervisor') NOT NULL DEFAULT 'vigilante' COMMENT 'Papel do docente no j├║ri',
  `juri_inicio` datetime DEFAULT NULL COMMENT 'Janela temporal materializada (desnormaliza├º├úo para performance)',
  `juri_fim` datetime DEFAULT NULL COMMENT 'Janela temporal materializada',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jury_vigilante` (`jury_id`,`vigilante_id`),
  KEY `fk_jv_assigned_by` (`assigned_by`),
  KEY `idx_jv_vigilante_datetime` (`vigilante_id`,`jury_exam_date`,`jury_start_time`,`jury_end_time`),
  KEY `idx_jv_docente_intervalo` (`vigilante_id`,`juri_inicio`,`juri_fim`),
  KEY `idx_jv_papel` (`jury_id`,`papel`),
  KEY `idx_jury_vigilantes_jury` (`jury_id`,`vigilante_id`),
  KEY `idx_jury_vigilantes_vigilante` (`vigilante_id`,`jury_id`),
  CONSTRAINT `fk_jv_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jv_jury` FOREIGN KEY (`jury_id`) REFERENCES `juries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jv_vigilante` FOREIGN KEY (`vigilante_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jury_vigilantes`
--

LOCK TABLES `jury_vigilantes` WRITE;
/*!40000 ALTER TABLE `jury_vigilantes` DISABLE KEYS */;
INSERT INTO `jury_vigilantes` VALUES (8,7,10,'2026-02-01','08:00:00','10:00:00',1,'2026-01-31 21:13:45','vigilante',NULL,NULL),(9,8,3,'2026-02-01','08:00:00','10:00:00',1,'2026-01-31 21:13:45','vigilante',NULL,NULL),(10,9,9,'2026-02-01','08:00:00','10:00:00',1,'2026-01-31 21:21:06','vigilante',NULL,NULL),(11,9,4,'2026-02-01','08:00:00','10:00:00',1,'2026-01-31 21:21:06','vigilante',NULL,NULL),(12,10,21,'2026-02-19','20:00:00','22:00:00',1,'2026-02-18 15:52:28','vigilante',NULL,NULL);
/*!40000 ALTER TABLE `jury_vigilantes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017*/ /*!50003 TRIGGER trg_check_vigilantes_capacity 
BEFORE INSERT ON jury_vigilantes
FOR EACH ROW
BEGIN
    DECLARE v_capacity INT;
    DECLARE v_current_count INT;
    DECLARE v_exam_date DATE;
    DECLARE v_start_time TIME;
    DECLARE v_end_time TIME;
    SELECT vigilantes_capacity, exam_date, start_time, end_time
    INTO v_capacity, v_exam_date, v_start_time, v_end_time
    FROM juries 
    WHERE id = NEW.jury_id;
    SELECT COUNT(*) 
    INTO v_current_count
    FROM jury_vigilantes 
    WHERE jury_id = NEW.jury_id;
    IF v_current_count >= v_capacity THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Capacidade máxima de vigilantes atingida para este júri';
    END IF;
    SET NEW.jury_exam_date = v_exam_date;
    SET NEW.jury_start_time = v_start_time;
    SET NEW.jury_end_time = v_end_time;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017*/ /*!50003 TRIGGER trg_check_vigilante_conflicts
BEFORE INSERT ON jury_vigilantes
FOR EACH ROW
BEGIN
    DECLARE v_conflict_count INT;
    SELECT COUNT(*)
    INTO v_conflict_count
    FROM jury_vigilantes jv
    INNER JOIN juries j ON j.id = jv.jury_id
    WHERE jv.vigilante_id = NEW.vigilante_id
      AND j.exam_date = (SELECT exam_date FROM juries WHERE id = NEW.jury_id)
      AND j.id != NEW.jury_id
      AND (
          (j.start_time < (SELECT end_time FROM juries WHERE id = NEW.jury_id))
          AND
          ((SELECT start_time FROM juries WHERE id = NEW.jury_id) < j.end_time)
      );
    IF v_conflict_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Vigilante já está alocado em júri com horário conflitante no mesmo dia';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017*/ /*!50003 TRIGGER trg_jv_check_cap
BEFORE INSERT ON jury_vigilantes
FOR EACH ROW
BEGIN
  DECLARE cap INT DEFAULT 0;
  DECLARE qtd INT DEFAULT 0;
  
  IF NEW.papel = 'vigilante' THEN
    
    SELECT vigilantes_capacidade INTO cap
    FROM juries
    WHERE id = NEW.jury_id;
    
    
    SELECT COUNT(*) INTO qtd
    FROM jury_vigilantes
    WHERE jury_id = NEW.jury_id AND papel = 'vigilante';
    
    
    IF qtd >= cap THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Capacidade de vigilantes atingida';
    END IF;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017*/ /*!50003 TRIGGER trg_jv_supervisor_unico
BEFORE INSERT ON jury_vigilantes
FOR EACH ROW
BEGIN
  DECLARE existe INT DEFAULT 0;
  
  IF NEW.papel = 'supervisor' THEN
    
    SELECT COUNT(*) INTO existe
    FROM jury_vigilantes
    WHERE jury_id = NEW.jury_id AND papel = 'supervisor';
    
    
    IF existe > 0 THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Júri já possui supervisor';
    END IF;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017*/ /*!50003 TRIGGER trg_jv_no_overlap_ins
BEFORE INSERT ON jury_vigilantes
FOR EACH ROW
BEGIN
  DECLARE confl INT DEFAULT 0;
  DECLARE inicio_novo DATETIME;
  DECLARE fim_novo DATETIME;
  
  
  SELECT inicio, fim INTO inicio_novo, fim_novo
  FROM juries
  WHERE id = NEW.jury_id;
  
  
  
  SELECT COUNT(*) INTO confl
  FROM jury_vigilantes jv
  WHERE jv.vigilante_id = NEW.vigilante_id
    AND jv.juri_inicio IS NOT NULL
    AND jv.juri_fim IS NOT NULL
    AND fim_novo > jv.juri_inicio
    AND inicio_novo < jv.juri_fim;
  
  
  IF confl > 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Conflito de horário';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017*/ /*!50003 TRIGGER trg_jv_no_overlap_upd
BEFORE UPDATE ON jury_vigilantes
FOR EACH ROW
BEGIN
  DECLARE confl INT DEFAULT 0;
  DECLARE inicio_novo DATETIME;
  DECLARE fim_novo DATETIME;
  
  
  IF NEW.jury_id != OLD.jury_id OR NEW.vigilante_id != OLD.vigilante_id THEN
    
    SELECT inicio, fim INTO inicio_novo, fim_novo
    FROM juries
    WHERE id = NEW.jury_id;
    
    
    SELECT COUNT(*) INTO confl
    FROM jury_vigilantes jv
    WHERE jv.vigilante_id = NEW.vigilante_id
      AND jv.id != NEW.id
      AND jv.juri_inicio IS NOT NULL
      AND jv.juri_fim IS NOT NULL
      AND fim_novo > jv.juri_inicio
      AND inicio_novo < jv.juri_fim;
    
    IF confl > 0 THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Conflito de horário';
    END IF;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `location_stats`
--

DROP TABLE IF EXISTS `location_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(150) NOT NULL,
  `exam_date` date NOT NULL,
  `total_juries` int(11) NOT NULL DEFAULT 0,
  `total_disciplines` int(11) NOT NULL DEFAULT 0,
  `total_candidates` int(11) NOT NULL DEFAULT 0,
  `total_vigilantes` int(11) NOT NULL DEFAULT 0,
  `total_supervisors` int(11) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_location_stats` (`location`,`exam_date`),
  KEY `idx_location_stats_date` (`exam_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_stats`
--

LOCK TABLES `location_stats` WRITE;
/*!40000 ALTER TABLE `location_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_template_disciplines`
--

DROP TABLE IF EXISTS `location_template_disciplines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_template_disciplines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `subject` varchar(180) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template_disciplines_template` (`template_id`),
  CONSTRAINT `fk_template_disciplines_template` FOREIGN KEY (`template_id`) REFERENCES `location_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_template_disciplines`
--

LOCK TABLES `location_template_disciplines` WRITE;
/*!40000 ALTER TABLE `location_template_disciplines` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_template_disciplines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_template_rooms`
--

DROP TABLE IF EXISTS `location_template_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_template_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discipline_id` int(11) NOT NULL,
  `room` varchar(60) NOT NULL,
  `candidates_quota` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template_rooms_discipline` (`discipline_id`),
  CONSTRAINT `fk_template_rooms_discipline` FOREIGN KEY (`discipline_id`) REFERENCES `location_template_disciplines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_template_rooms`
--

LOCK TABLES `location_template_rooms` WRITE;
/*!40000 ALTER TABLE `location_template_rooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_template_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_templates`
--

DROP TABLE IF EXISTS `location_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `location` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_location_templates_created_by` (`created_by`),
  KEY `idx_location_templates_active` (`is_active`),
  CONSTRAINT `fk_location_templates_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_templates`
--

LOCK TABLES `location_templates` WRITE;
/*!40000 ALTER TABLE `location_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_channels`
--

DROP TABLE IF EXISTS `notification_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_channels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) NOT NULL,
  `channel` enum('internal','email','sms') NOT NULL,
  `status` enum('pending','sent','failed') DEFAULT 'pending',
  `sent_at` timestamp NULL DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_notification` (`notification_id`),
  KEY `idx_channel` (`channel`),
  CONSTRAINT `notification_channels_ibfk_1` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_channels`
--

LOCK TABLES `notification_channels` WRITE;
/*!40000 ALTER TABLE `notification_channels` DISABLE KEYS */;
INSERT INTO `notification_channels` VALUES (4,1,'internal','sent','2026-01-17 14:23:02',NULL),(5,1,'email','sent','2026-01-17 14:23:04',NULL),(6,2,'internal','sent','2026-01-31 18:38:43',NULL),(7,2,'email','sent','2026-01-31 18:38:45',NULL),(8,3,'internal','sent','2026-01-31 18:38:47',NULL),(9,3,'email','sent','2026-01-31 18:38:49',NULL),(10,4,'internal','sent','2026-01-31 18:38:51',NULL),(11,4,'email','sent','2026-01-31 18:38:54',NULL),(12,5,'internal','sent','2026-01-31 18:38:56',NULL),(13,5,'email','sent','2026-01-31 18:38:58',NULL),(14,6,'internal','sent','2026-01-31 18:39:00',NULL),(15,7,'internal','sent','2026-01-31 18:39:04',NULL),(16,7,'email','sent','2026-01-31 18:39:06',NULL),(17,8,'internal','sent','2026-01-31 18:39:08',NULL),(18,8,'email','sent','2026-01-31 18:39:10',NULL),(19,9,'internal','sent','2026-01-31 18:39:12',NULL),(20,9,'email','sent','2026-01-31 18:39:14',NULL),(21,10,'internal','sent','2026-01-18 13:04:48',NULL),(22,10,'email','sent','2026-01-18 13:04:50',NULL),(23,11,'internal','sent','2026-02-18 13:14:18',NULL),(24,11,'email','sent','2026-02-18 13:14:20',NULL),(25,12,'internal','sent','2026-01-18 13:06:45',NULL),(26,12,'email','sent','2026-01-18 13:06:47',NULL),(27,13,'internal','sent','2026-01-18 14:31:09',NULL),(28,13,'email','sent','2026-01-18 14:31:11',NULL),(29,14,'internal','sent','2026-01-18 14:31:51',NULL),(30,14,'email','sent','2026-01-18 14:31:53',NULL),(31,15,'internal','sent','2026-01-18 14:32:40',NULL),(32,15,'email','sent','2026-01-18 14:32:42',NULL),(33,16,'internal','sent','2026-01-18 14:33:07',NULL),(34,16,'email','sent','2026-01-18 14:33:09',NULL),(35,17,'internal','sent','2026-01-18 14:34:10',NULL),(36,17,'email','sent','2026-01-18 14:34:12',NULL),(37,18,'internal','sent','2026-01-18 14:34:30',NULL),(38,18,'email','sent','2026-01-18 14:34:32',NULL),(39,19,'internal','sent','2026-01-18 14:53:15',NULL),(40,19,'email','sent','2026-01-18 14:53:17',NULL),(41,20,'internal','sent','2026-01-18 14:53:25',NULL),(42,20,'email','sent','2026-01-18 14:53:27',NULL),(43,21,'internal','sent','2026-01-18 15:06:30',NULL),(44,21,'email','sent','2026-01-18 15:06:32',NULL),(45,22,'internal','sent','2026-01-18 15:21:04',NULL),(46,22,'email','sent','2026-01-18 15:21:06',NULL),(47,23,'internal','sent','2026-01-18 15:22:06',NULL),(48,23,'email','sent','2026-01-18 15:22:08',NULL),(49,24,'internal','sent','2026-01-19 14:19:14',NULL),(50,24,'email','sent','2026-01-19 14:19:16',NULL),(51,25,'internal','sent','2026-01-19 14:19:58',NULL),(52,25,'email','sent','2026-01-19 14:20:00',NULL),(53,26,'internal','sent','2026-01-19 14:22:25',NULL),(54,26,'email','sent','2026-01-19 14:22:27',NULL),(55,27,'internal','sent','2026-01-19 14:27:49',NULL),(56,27,'email','sent','2026-01-19 14:27:51',NULL),(57,28,'internal','sent','2026-01-19 14:28:19',NULL),(58,28,'email','sent','2026-01-19 14:28:21',NULL),(59,29,'internal','sent','2026-01-20 12:08:10',NULL),(60,29,'email','sent','2026-01-20 12:08:12',NULL),(61,30,'internal','sent','2026-01-20 12:08:19',NULL),(62,30,'email','sent','2026-01-20 12:08:21',NULL),(63,31,'internal','sent','2026-01-20 12:36:19',NULL),(64,32,'internal','sent','2026-01-20 12:42:23',NULL),(65,33,'internal','sent','2026-01-20 13:04:55',NULL),(66,33,'email','sent','2026-01-20 13:04:57',NULL),(67,34,'internal','sent','2026-01-20 13:04:59',NULL),(68,34,'email','sent','2026-01-20 13:05:01',NULL),(69,35,'internal','sent','2026-01-20 13:05:03',NULL),(70,35,'email','sent','2026-01-20 13:05:05',NULL),(71,36,'internal','sent','2026-01-20 13:05:07',NULL),(72,36,'email','sent','2026-01-20 13:05:10',NULL),(73,37,'internal','sent','2026-01-20 13:05:12',NULL),(74,37,'email','sent','2026-01-20 13:05:14',NULL),(75,38,'internal','sent','2026-01-20 13:05:16',NULL),(76,38,'email','sent','2026-01-20 13:05:18',NULL),(77,39,'internal','sent','2026-01-20 13:05:20',NULL),(78,39,'email','sent','2026-01-20 13:05:22',NULL),(79,40,'internal','sent','2026-01-20 13:05:24',NULL),(80,40,'email','sent','2026-01-20 13:05:26',NULL),(81,41,'internal','sent','2026-01-20 13:05:28',NULL),(82,41,'email','sent','2026-01-20 13:05:30',NULL),(83,42,'internal','sent','2026-01-20 13:07:32',NULL),(84,42,'email','sent','2026-01-20 13:07:34',NULL),(85,43,'internal','sent','2026-01-20 13:08:26',NULL),(86,43,'email','sent','2026-01-20 13:08:28',NULL),(87,44,'internal','sent','2026-01-20 13:08:30',NULL),(88,44,'email','sent','2026-01-20 13:08:32',NULL),(89,45,'internal','sent','2026-01-20 13:08:34',NULL),(90,45,'email','sent','2026-01-20 13:08:36',NULL),(91,46,'internal','sent','2026-01-20 13:08:38',NULL),(92,46,'email','sent','2026-01-20 13:08:40',NULL),(93,47,'internal','sent','2026-01-20 13:08:42',NULL),(94,47,'email','sent','2026-01-20 13:08:44',NULL),(95,48,'internal','sent','2026-01-20 13:08:47',NULL),(96,48,'email','sent','2026-01-20 13:08:49',NULL),(97,49,'internal','sent','2026-01-20 13:08:51',NULL),(98,49,'email','sent','2026-01-20 13:08:53',NULL),(99,50,'internal','sent','2026-01-20 13:08:55',NULL),(100,50,'email','sent','2026-01-20 13:08:57',NULL),(101,2,'internal','sent','2026-01-31 18:38:43',NULL),(102,2,'email','sent','2026-01-31 18:38:45',NULL),(103,3,'internal','sent','2026-01-31 18:38:47',NULL),(104,3,'email','sent','2026-01-31 18:38:49',NULL),(105,4,'internal','sent','2026-01-31 18:38:51',NULL),(106,4,'email','sent','2026-01-31 18:38:54',NULL),(107,5,'internal','sent','2026-01-31 18:38:56',NULL),(108,5,'email','sent','2026-01-31 18:38:58',NULL),(109,6,'internal','sent','2026-01-31 18:39:00',NULL),(110,6,'email','sent','2026-01-31 18:39:02',NULL),(111,7,'internal','sent','2026-01-31 18:39:04',NULL),(112,7,'email','sent','2026-01-31 18:39:06',NULL),(113,8,'internal','sent','2026-01-31 18:39:08',NULL),(114,8,'email','sent','2026-01-31 18:39:10',NULL),(115,9,'internal','sent','2026-01-31 18:39:12',NULL),(116,9,'email','sent','2026-01-31 18:39:14',NULL),(117,11,'internal','sent','2026-02-18 13:14:18',NULL),(118,11,'email','sent','2026-02-18 13:14:20',NULL);
/*!40000 ALTER TABLE `notification_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_recipients`
--

DROP TABLE IF EXISTS `notification_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_recipients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_recipient` (`notification_id`,`user_id`),
  KEY `idx_user_unread` (`user_id`,`read_at`),
  KEY `idx_notification` (`notification_id`),
  CONSTRAINT `notification_recipients_ibfk_1` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notification_recipients_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_recipients`
--

LOCK TABLES `notification_recipients` WRITE;
/*!40000 ALTER TABLE `notification_recipients` DISABLE KEYS */;
INSERT INTO `notification_recipients` VALUES (2,1,2,'2026-01-31 17:54:30','2026-01-31 17:53:26'),(4,1,4,NULL,'2026-01-31 17:53:26'),(5,1,5,NULL,'2026-01-31 17:53:26'),(6,1,6,NULL,'2026-01-31 17:53:26'),(7,1,7,NULL,'2026-01-31 17:53:26'),(8,1,8,NULL,'2026-01-31 17:53:26'),(9,1,9,NULL,'2026-01-31 17:53:26'),(10,1,10,NULL,'2026-01-31 17:53:26'),(11,1,11,NULL,'2026-01-31 17:53:26'),(12,1,12,NULL,'2026-01-31 17:53:26'),(13,1,13,NULL,'2026-01-31 17:53:26'),(14,1,14,NULL,'2026-01-31 17:53:26'),(15,1,15,NULL,'2026-01-31 17:53:26'),(16,1,16,NULL,'2026-01-31 17:53:26'),(17,1,17,NULL,'2026-01-31 17:53:26'),(18,1,18,NULL,'2026-01-31 17:53:26'),(19,1,19,NULL,'2026-01-31 17:53:26'),(20,1,20,NULL,'2026-01-31 17:53:26'),(21,2,10,NULL,'2026-01-31 18:38:43'),(22,3,9,NULL,'2026-01-31 18:38:47'),(23,4,8,NULL,'2026-01-31 18:38:51'),(24,5,7,NULL,'2026-01-31 18:38:56'),(25,6,6,NULL,'2026-01-31 18:39:00'),(26,7,5,NULL,'2026-01-31 18:39:04'),(27,8,4,NULL,'2026-01-31 18:39:08'),(28,9,3,'2026-02-18 12:14:35','2026-01-31 18:39:12'),(29,10,1,'2026-02-18 12:52:21','2026-02-18 12:52:03'),(30,10,2,NULL,'2026-02-18 12:52:03'),(31,10,3,'2026-02-19 09:26:22','2026-02-18 12:52:03'),(32,10,4,NULL,'2026-02-18 12:52:03'),(33,10,5,NULL,'2026-02-18 12:52:03'),(34,10,6,NULL,'2026-02-18 12:52:03'),(35,10,7,NULL,'2026-02-18 12:52:03'),(36,10,8,NULL,'2026-02-18 12:52:03'),(37,10,9,NULL,'2026-02-18 12:52:03'),(38,10,10,NULL,'2026-02-18 12:52:03'),(39,10,11,NULL,'2026-02-18 12:52:03'),(40,10,12,NULL,'2026-02-18 12:52:03'),(41,10,13,NULL,'2026-02-18 12:52:03'),(42,10,14,NULL,'2026-02-18 12:52:03'),(43,10,15,NULL,'2026-02-18 12:52:03'),(44,10,16,NULL,'2026-02-18 12:52:03'),(45,10,17,NULL,'2026-02-18 12:52:03'),(46,10,18,NULL,'2026-02-18 12:52:03'),(47,10,19,NULL,'2026-02-18 12:52:03'),(48,10,20,NULL,'2026-02-18 12:52:03'),(49,11,21,'2026-02-18 13:15:55','2026-02-18 13:14:18');
/*!40000 ALTER TABLE `notification_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('informativa','alerta','urgente') NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `context_type` varchar(50) DEFAULT NULL COMMENT 'jury, exam, payment, report, user, general',
  `context_id` int(11) DEFAULT NULL,
  `is_automatic` tinyint(1) DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_context` (`context_type`,`context_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_type` (`type`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,'','Nova Vaga Disponível','Uma nova vaga foi publicada: exames 2026. Prazo até 07/02/2026','vacancy',3,1,1,'2026-01-31 17:53:26'),(2,'alerta','Candidatura Aprovada: exames 2026','Parabéns! Sua candidatura para a vaga \'exames 2026\' foi aprovada.','vacancy_application',8,1,NULL,'2026-01-31 18:38:43'),(3,'alerta','Candidatura Aprovada: exames 2026','Parabéns! Sua candidatura para a vaga \'exames 2026\' foi aprovada.','vacancy_application',7,1,NULL,'2026-01-31 18:38:47'),(4,'alerta','Candidatura Aprovada: exames 2026','Parabéns! Sua candidatura para a vaga \'exames 2026\' foi aprovada.','vacancy_application',6,1,NULL,'2026-01-31 18:38:51'),(5,'alerta','Candidatura Aprovada: exames 2026','Parabéns! Sua candidatura para a vaga \'exames 2026\' foi aprovada.','vacancy_application',5,1,NULL,'2026-01-31 18:38:56'),(6,'alerta','Candidatura Aprovada: exames 2026','Parabéns! Sua candidatura para a vaga \'exames 2026\' foi aprovada.','vacancy_application',4,1,NULL,'2026-01-31 18:39:00'),(7,'alerta','Candidatura Aprovada: exames 2026','Parabéns! Sua candidatura para a vaga \'exames 2026\' foi aprovada.','vacancy_application',3,1,NULL,'2026-01-31 18:39:04'),(8,'alerta','Candidatura Aprovada: exames 2026','Parabéns! Sua candidatura para a vaga \'exames 2026\' foi aprovada.','vacancy_application',2,1,NULL,'2026-01-31 18:39:08'),(9,'alerta','Candidatura Aprovada: exames 2026','Parabéns! Sua candidatura para a vaga \'exames 2026\' foi aprovada.','vacancy_application',1,1,NULL,'2026-01-31 18:39:12'),(10,'','Nova Vaga Disponível','Uma nova vaga foi publicada: Exames de Admissao 2027. Prazo até 26/02/2026','vacancy',4,1,1,'2026-02-18 12:52:03'),(11,'alerta','Candidatura Aprovada: Exames de Admissao 2027','Parabéns! Sua candidatura para a vaga \'Exames de Admissao 2027\' foi aprovada.','vacancy_application',9,1,NULL,'2026-02-18 13:14:18');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_requests`
--

DROP TABLE IF EXISTS `password_reset_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by` int(11) DEFAULT NULL,
  `new_temp_password` varchar(255) DEFAULT NULL,
  `status` enum('pending','resolved','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resolved_by` (`resolved_by`),
  KEY `idx_status` (`status`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `password_reset_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `password_reset_requests_ibfk_2` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_requests`
--

LOCK TABLES `password_reset_requests` WRITE;
/*!40000 ALTER TABLE `password_reset_requests` DISABLE KEYS */;
INSERT INTO `password_reset_requests` VALUES (1,15,'2026-01-18 11:48:20','2026-01-18 12:31:13',1,'32188832','resolved',NULL),(2,15,'2026-01-18 13:04:41',NULL,NULL,NULL,'pending',NULL),(3,15,'2026-01-18 13:04:43','2026-01-18 13:05:24',1,'Password@2025','resolved',NULL),(4,15,'2026-01-18 13:04:46',NULL,NULL,NULL,'pending',NULL),(5,15,'2026-01-18 13:04:48',NULL,NULL,NULL,'pending',NULL),(6,19,'2026-01-18 14:31:09','2026-01-18 14:31:51',1,'f4856d9c','resolved',NULL),(7,19,'2026-01-18 14:32:40','2026-01-18 14:33:07',1,'wswdweefer69566','resolved',NULL),(8,19,'2026-01-18 14:34:10','2026-01-18 14:34:30',1,'9543fbce','resolved',NULL),(9,20,'2026-01-19 14:27:49','2026-01-19 14:28:19',1,'71efb3e5','resolved',NULL);
/*!40000 ALTER TABLE `password_reset_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `token` varchar(100) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_password_resets_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_rates`
--

DROP TABLE IF EXISTS `payment_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vacancy_id` int(11) NOT NULL,
  `valor_por_vigia` decimal(10,2) NOT NULL DEFAULT 0.00,
  `valor_por_supervisao` decimal(10,2) NOT NULL DEFAULT 0.00,
  `moeda` varchar(3) NOT NULL DEFAULT 'MZN',
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vacancy_active` (`vacancy_id`,`ativo`),
  CONSTRAINT `payment_rates_ibfk_1` FOREIGN KEY (`vacancy_id`) REFERENCES `exam_vacancies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_rates`
--

LOCK TABLES `payment_rates` WRITE;
/*!40000 ALTER TABLE `payment_rates` DISABLE KEYS */;
INSERT INTO `payment_rates` VALUES (3,3,997.50,1995.00,'MZN',1,'2026-02-18 12:28:17','2026-02-18 12:28:17'),(4,4,997.50,1995.00,'MZN',1,'2026-02-18 13:25:55','2026-02-18 13:25:55');
/*!40000 ALTER TABLE `payment_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vacancy_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nr_vigias` int(11) NOT NULL DEFAULT 0,
  `nr_supervisoes` int(11) NOT NULL DEFAULT 0,
  `valor_vigias` decimal(10,2) NOT NULL DEFAULT 0.00,
  `valor_supervisoes` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estado` enum('previsto','validado','pago') NOT NULL DEFAULT 'previsto',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `validated_at` timestamp NULL DEFAULT NULL,
  `validated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_payment` (`vacancy_id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `validated_by` (`validated_by`),
  KEY `idx_vacancy_estado` (`vacancy_id`,`estado`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`vacancy_id`) REFERENCES `exam_vacancies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`validated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,4,21,1,0,997.50,0.00,997.50,'previsto','2026-02-18 14:03:22',NULL,NULL),(2,4,22,0,1,0.00,1995.00,1995.00,'previsto','2026-02-18 14:03:22',NULL,NULL);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_questions`
--

DROP TABLE IF EXISTS `security_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_questions`
--

LOCK TABLES `security_questions` WRITE;
/*!40000 ALTER TABLE `security_questions` DISABLE KEYS */;
INSERT INTO `security_questions` VALUES (1,'Qual o nome do seu primeiro animal de estimação?',1,'2026-01-18 14:02:18'),(2,'Qual o nome da sua escola primária?',1,'2026-01-18 14:02:18'),(3,'Qual o apelido de solteira da sua mãe?',1,'2026-01-18 14:02:18'),(4,'Em que cidade você nasceu?',1,'2026-01-18 14:02:18'),(5,'Qual seu filme favorito?',1,'2026-01-18 14:02:18'),(6,'Qual a marca do seu primeiro carro?',1,'2026-01-18 14:02:18');
/*!40000 ALTER TABLE `security_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_audit_log`
--

DROP TABLE IF EXISTS `user_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_audit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `details` text DEFAULT NULL,
  `performed_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `performed_by` (`performed_by`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_action` (`action`),
  CONSTRAINT `user_audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_audit_log_ibfk_2` FOREIGN KEY (`performed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_audit_log`
--

LOCK TABLES `user_audit_log` WRITE;
/*!40000 ALTER TABLE `user_audit_log` DISABLE KEYS */;
INSERT INTO `user_audit_log` VALUES (1,13,'role_added','Papel \'vigilante\' adicionado',1,'2026-01-17 09:36:47'),(2,16,'role_added','Papel \'vigilante\' adicionado',1,'2026-01-18 11:02:48'),(3,16,'reactivated','Conta reativada',1,'2026-01-18 11:07:10'),(4,16,'reactivated','Conta reativada',1,'2026-01-18 11:07:21'),(5,16,'reactivated','Conta reativada',1,'2026-01-18 11:07:28'),(6,17,'role_added','Papel \'vigilante\' adicionado',1,'2026-01-18 11:16:56'),(7,19,'reactivated','Conta reativada',1,'2026-01-19 13:15:11'),(8,19,'reactivated','Conta reativada',1,'2026-01-19 13:15:20'),(9,19,'role_added','Papel \'vigilante\' adicionado',1,'2026-01-19 13:15:29'),(10,20,'role_added','Papel \'membro\' adicionado',1,'2026-01-19 14:29:39'),(11,20,'promotion','Promovido a Membro da Comissão',1,'2026-01-19 14:29:39');
/*!40000 ALTER TABLE `user_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role` enum('vigilante','supervisor','membro','coordenador') NOT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_role` (`user_id`,`role`),
  KEY `assigned_by` (`assigned_by`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_role` (`role`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1,'coordenador',NULL,'2025-10-08 21:08:17'),(2,2,'membro',NULL,'2025-10-08 21:08:17'),(3,3,'vigilante',NULL,'2025-10-08 21:08:17'),(4,4,'vigilante',NULL,'2025-10-08 21:08:17'),(5,5,'vigilante',NULL,'2025-10-09 10:50:41'),(6,6,'vigilante',NULL,'2025-10-09 10:51:01'),(7,7,'vigilante',NULL,'2025-10-09 10:51:29'),(8,8,'vigilante',NULL,'2025-10-11 15:38:33'),(9,9,'vigilante',NULL,'2025-10-11 16:53:16'),(10,10,'vigilante',NULL,'2025-10-11 17:04:28'),(11,11,'vigilante',NULL,'2025-10-11 21:04:49'),(12,12,'vigilante',NULL,'2026-01-08 07:43:43'),(16,1,'membro',NULL,'2025-10-08 21:08:17'),(17,13,'vigilante',1,'2026-01-17 09:36:47'),(18,16,'vigilante',1,'2026-01-18 11:02:48'),(19,17,'vigilante',1,'2026-01-18 11:16:56'),(20,19,'vigilante',1,'2026-01-19 13:15:29'),(21,20,'membro',1,'2026-01-19 14:29:39');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_security_answers`
--

DROP TABLE IF EXISTS `user_security_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_security_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer_hash` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `fk_usa_question` FOREIGN KEY (`question_id`) REFERENCES `security_questions` (`id`),
  CONSTRAINT `fk_usa_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_security_answers`
--

LOCK TABLES `user_security_answers` WRITE;
/*!40000 ALTER TABLE `user_security_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_security_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `gender` enum('M','F','O') DEFAULT 'M',
  `birth_date` date DEFAULT NULL,
  `document_type` varchar(50) DEFAULT NULL,
  `document_number` varchar(50) DEFAULT NULL,
  `origin_university` varchar(150) DEFAULT NULL,
  `university` varchar(150) DEFAULT NULL,
  `nuit` varchar(30) DEFAULT NULL,
  `degree` enum('Licenciado','Mestre','Doutor') DEFAULT 'Licenciado',
  `major_area` varchar(150) DEFAULT NULL,
  `bank_name` varchar(120) DEFAULT NULL,
  `nib` varchar(32) DEFAULT NULL,
  `bank_account_holder` varchar(150) DEFAULT NULL,
  `role` enum('coordenador','membro','supervisor','vigilante') NOT NULL DEFAULT 'vigilante',
  `password_hash` varchar(255) NOT NULL,
  `recovery_keyword_hash` varchar(255) DEFAULT NULL,
  `recovery_pin_hash` varchar(255) DEFAULT NULL,
  `must_change_password` tinyint(1) DEFAULT 0,
  `temp_password_at` timestamp NULL DEFAULT NULL,
  `profile_complete` tinyint(1) DEFAULT 0,
  `email_verified_at` datetime DEFAULT NULL,
  `verification_token` varchar(120) DEFAULT NULL,
  `avatar_url` varchar(255) DEFAULT NULL,
  `supervisor_eligible` tinyint(1) NOT NULL DEFAULT 0,
  `available_for_vigilance` tinyint(1) NOT NULL DEFAULT 0,
  `profile_completed` tinyint(1) NOT NULL DEFAULT 0,
  `profile_completed_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `banco` varchar(100) DEFAULT NULL,
  `numero_conta` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `deactivated_at` timestamp NULL DEFAULT NULL,
  `deactivation_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  KEY `fk_users_created_by` (`created_by`),
  KEY `idx_users_availability` (`available_for_vigilance`,`supervisor_eligible`),
  KEY `idx_users_profile_vigilante` (`role`,`profile_completed`,`available_for_vigilance`),
  KEY `idx_users_available` (`available_for_vigilance`,`role`),
  KEY `idx_users_supervisor` (`supervisor_eligible`,`role`),
  KEY `idx_users_active` (`is_active`),
  KEY `idx_users_email` (`email`),
  CONSTRAINT `fk_users_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'EGAS LUIS FREDERICO LEMOS','coordenador','coordenador@unilicungo.ac.mz','+258 840000001','M',NULL,NULL,NULL,'Universidade Católica de Moçambique (UCM)','UniLicungo','123456789','Mestre','Gestao Educacional','Millennium BIM','56555555555555555555555',NULL,'coordenador','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-08 23:08:17',NULL,NULL,0,0,1,'2025-10-14 03:25:25',NULL,'2025-10-08 23:08:17','2025-10-14 03:25:39',NULL,NULL,1,NULL,NULL),(2,'Membro Comissao','membro','membro@unilicungo.ac.mz','+258840000002','F',NULL,NULL,NULL,NULL,'UniLicungo','223456789','Licenciado','Administracao','BCI','000000000000000000002',NULL,'membro','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-08 23:08:17',NULL,NULL,0,1,0,NULL,1,'2025-10-08 23:08:17','2025-10-08 23:08:17',NULL,NULL,1,NULL,NULL),(3,'Vigilante Joao','vigilante1','vigilante1@unilicungo.ac.mz','+258 84 378 9152','M','2026-01-20','Passaporte','110100188065I','Universidade Católica de Moçambique (UCM)','UniLicungo','323456789','Licenciado','Matematica','Standard Bank','21111111111111111111111','Vigilante Joao','vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-08 23:08:17',NULL,NULL,0,1,1,'2025-10-11 17:52:38',NULL,'2025-10-08 23:08:17','2026-01-20 14:58:01',NULL,NULL,1,NULL,NULL),(4,'Vigilante Maria','vigilante2','vigilante2@unilicungo.ac.mz','+258 840000004','F','2026-01-20','BI','110100188065I','Instituto Superior de Ciências da Saúde (ISCISA)','UniLicungo','423456789','Doutor','Biologia','Millennium BIM','12345678912345678912345','Vigilante Maria','vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-08 23:08:17',NULL,NULL,0,1,1,'2025-10-11 17:52:38',NULL,'2025-10-08 23:08:17','2026-01-20 14:49:00',NULL,NULL,1,NULL,NULL),(5,'Vigilante Taimo','vigilante3','vigilante3@unilicungo.ac.mz','+258 87 378 9152','M','2026-01-20','Passaporte','110100188065I','Universidade São Tomás de Moçambique (USTM)','UniLicungo','898989898','Licenciado','Gestao Educacional','Banco de Moçambique (BM)','12345678910111213141516','Vigilante Taimo','vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-09 12:50:41',NULL,NULL,1,1,1,'2025-10-13 15:44:37',NULL,'2025-10-09 12:50:41','2026-01-20 14:49:36',NULL,NULL,1,NULL,NULL),(6,'Vigilante Nadia','vigilante4','vigilante4@unilicungo.ac.mz','+258 843789152','M','2026-02-04','BI','110100188065I','Universidade Licungo (UniLicungo)','UniLicungo','123456789','Licenciado','Gestão Educacional','Millennium BIM','12345678912345677899566','Vigilante Nadia','vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-09 12:51:01',NULL,NULL,1,1,1,'2026-01-20 14:50:43',NULL,'2025-10-09 12:51:01','2026-01-20 14:50:43',NULL,NULL,1,NULL,NULL),(7,'Vigilante Raul','vigilante5','vigilante5@unilicungo.ac.mz','+258 873789152','M','2026-01-20','BI','110100188065I','Universidade Pedagógica (UP)','UniLicungo','656565656','Licenciado','Gestão Educacional','Millennium BIM','31313131313131331313131','Vigilante Raul','vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-09 12:51:29',NULL,NULL,1,1,1,'2026-01-06 19:39:57',NULL,'2025-10-09 12:51:29','2026-01-20 14:52:16',NULL,NULL,1,NULL,NULL),(8,'Vigilante Pix','vigilante6','vigilante6@unilicungo.ac.mz','+258 843789152','M','2026-01-20','BI','110100188065I','Instituto Superior Monitor (ISM)','UniLicungo','123456789','Licenciado','Gestão Educacional','Millennium BIM','12345678912345678912345','Vigilante Pix','vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-11 17:38:33',NULL,'/uploads/avatars/avatar_8_1760198058.png',0,1,1,'2026-01-20 14:53:07',NULL,'2025-10-11 17:38:33','2026-01-20 14:53:07',NULL,NULL,1,NULL,NULL),(9,'cycode360','vigilante7','vigilante7@unilicungo.ac.mz','+258 87 378 9152','M','2026-01-20','DIRE','110100188065I','Universidade Católica de Moçambique (UCM)','UniLicungo','898989898','Licenciado','Gestao Educacional','First National Bank (FNB)','12345678910111213141516','cycode360','vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-11 18:53:16',NULL,NULL,0,1,1,'2025-10-11 19:34:02',NULL,'2025-10-11 18:53:16','2026-01-20 14:54:03',NULL,NULL,1,NULL,NULL),(10,'Victoria Lemos','vigilante8','vigilante8@unilicungo.ac.mz','+258 87 378 9152','M','2026-01-20','BI','110100188065I','Instituto Superior de Tecnologias e Gestão (ISTEG)','UniLicungo','444444444','Licenciado','Gestao Educacional','Letshego Bank','12345678910111213141516','Victoria Lemos','vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-11 19:04:28',NULL,NULL,0,1,1,'2025-10-11 19:12:35',NULL,'2025-10-11 19:04:28','2026-01-20 14:54:41',NULL,NULL,1,NULL,NULL),(11,'Pascoa da Graca','vigilante9','vigilante9@unilicungo.ac.mz','+258 87 378 9152','F','2026-01-20','BI','110100188065I','Universidade Licungo (UniLicungo)','UniLicungo','898989898','Licenciado','Gestao Educacional','Banco Comercial e de Investimentos (BCI)','12345678910111213141516','Pascoa da Graca','vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,1,'2025-10-11 23:04:49',NULL,NULL,1,1,1,'2025-10-11 23:23:46',NULL,'2025-10-11 23:04:49','2026-01-20 14:55:21',NULL,NULL,1,NULL,NULL),(12,'IVO LEMOS','ilemos5','ilemos5@unilicungo.ac.mz',NULL,'M',NULL,NULL,NULL,NULL,NULL,NULL,'Licenciado',NULL,NULL,NULL,NULL,'vigilante','$2y$10$RzMn8twsnBvDgwMLuYq6I.yu3wZT6u2sL9glbnP4W6L1QTgwXKXQK',NULL,NULL,0,NULL,0,'2026-01-08 09:43:43',NULL,NULL,0,1,0,NULL,NULL,'2026-01-08 09:43:43','2026-01-08 09:43:43',NULL,NULL,1,NULL,NULL),(13,'Egas Lemos','egaslemos','egaslemos@gmail.com','843789152','M',NULL,NULL,NULL,NULL,NULL,NULL,'Licenciado',NULL,NULL,NULL,NULL,'vigilante','$2y$10$w7XBbw1tCp57hRRiiVTPjOVpNkaUtWiSRuEnmzS96JfJuuEfeVGBi',NULL,NULL,0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,NULL,'2026-01-17 11:36:47','0000-00-00 00:00:00',NULL,NULL,1,NULL,NULL),(14,'elemos','elemos','elemos@unilicungo.ac.mz','+258 87 378 9152','M','2026-02-07','BI','110100188065I','Unizambeze',NULL,'123254515','Licenciado','Gestão Educacional','Millennium BIM','12345678910111213141516','elemos','vigilante','$2y$10$WT8ddlOtIexZfe69FX8cxOTLuMSDwYbwrNTApud7ZH75KPyHklTDO',NULL,NULL,0,NULL,1,'2026-01-18 12:06:17',NULL,'/uploads/avatars/avatar_14_1768733290.jpg',0,0,1,'2026-01-18 12:47:38',NULL,'2026-01-18 12:06:17','2026-01-18 12:48:10',NULL,NULL,1,NULL,NULL),(15,'Nolan da Graca Egas Lemos','ndagraca','elemos90@gmail.com','+258 87 378 9152','M','2026-01-18','BI','110100188065I','',NULL,'123456789','Mestre','Gestão Educacional','Letshego','12345678910111213141516','Nolan da Graca Egas Lemos','vigilante','$2y$10$PhKJ.HekCvOnFzZ9HceKSOstB5VynGlsl41u0uY8jEASE/G1lNuFS',NULL,NULL,0,NULL,1,NULL,NULL,NULL,0,0,1,'2026-01-18 13:09:16',NULL,'2026-01-18 12:50:49','2026-01-18 15:05:46',NULL,NULL,1,NULL,NULL),(16,'Lemos uis','lluis','lemos@gmail.com','+258843789152','M',NULL,NULL,NULL,NULL,NULL,NULL,'Licenciado',NULL,NULL,NULL,NULL,'vigilante','$2y$10$Q4n8/S541MRWaj7MIe6rQOBNfDkO8/XHbvbgGUWOj97VMm/BMTbAa',NULL,NULL,1,'2026-01-18 11:02:48',0,NULL,NULL,NULL,0,0,0,NULL,NULL,'2026-01-18 13:02:48','2026-01-18 13:07:28',NULL,NULL,1,NULL,NULL),(17,'teste','tteste','t@gmail.com','+258843789152','M','2026-01-31','BI','1232656455I','UL',NULL,'123456789','Licenciado','Gestao Educacional','Outro','12345678910111213141516','teste','vigilante','$2y$10$Ez2iKKGzkAUh3n/IqEpUv.vsRs./65kRolG5Wy9LCcRTGrxbn3Rx.',NULL,NULL,0,NULL,1,NULL,NULL,NULL,0,0,1,'2026-01-18 13:19:41',NULL,'2026-01-18 13:16:56','2026-01-18 13:19:41',NULL,NULL,1,NULL,NULL),(18,'Marcelino Andre Antonio','mantonio','marcelino@gmail.com','+258843789152','M','2026-01-18','BI','1232656455I','Universidade Save (UniSave)','UniLicungo-Beira','123456789','Mestre','Matematica','M-Pesa','56555555555555555555555','Marcelino Andre Antonio','vigilante','$2y$10$htPUd6Q5zCWbuKGK7w1e3.CBI9kn3s.uDYEZ.Tx7Fpn5wZ3Ot5ur6',NULL,NULL,0,NULL,1,NULL,NULL,NULL,0,0,1,'2026-01-18 14:35:32',NULL,'2026-01-18 14:33:07','2026-01-18 14:35:32',NULL,NULL,1,NULL,NULL),(19,'Bruno Luis Frederico Lemos','blemos','brunolesmo@gmail.com','+258 843789152','M','2026-01-18','BI','1232656455I','Instituto Superior de Tecnologias e Gestão (ISTEG)','UniLicungo-Beira','123456789','Licenciado','Matematica','MozaBanco','56555555555555555555555','Bruno Luis Frederico Lemos','vigilante','$2y$10$Dk1zB.0RDje1hPMZAyTOVOVln5.3w.4J4zck40uGdlOF8g/DRwmYa',NULL,NULL,0,NULL,1,NULL,NULL,NULL,0,0,1,'2026-01-18 16:28:14',NULL,'2026-01-18 16:27:04','2026-01-19 15:15:20',NULL,NULL,1,NULL,NULL),(20,'Lourenço Mugabe','lmugabe','lmugabe@gmail.com','+258843789152','M','2026-01-31','BI','18282828383','Universidade Politécnica (UniPol)','UniLicungo','123456789','Licenciado','Informática','Moza Banco','12345678901234567890123','Lourenço Mugabe','membro','$2y$10$e8P8fcuAZr.FzHHDAKErCeeDqvca4ozsdgY6saWKFS4rAJ72UhvGe',NULL,NULL,1,'2026-01-19 14:28:19',1,NULL,NULL,NULL,0,0,1,'2026-01-19 15:58:38',NULL,'2026-01-19 15:54:08','2026-01-19 16:28:19',NULL,NULL,1,NULL,NULL),(21,'Helenio da Silva Joaquim','helenioj','hjoaquim@unilicungo.ac.mz','+258 878287751','M','1993-08-04','BI','1234567890N','Universidade Licungo (UniLicungo)','Universidade Licungo','198280249','Licenciado','Educacao','Millennium BIM','01000000247124379570000','Helenio da Silva Joaquim','vigilante','$2y$10$56itpEawCxSUQhuDKTWOBuFLLRXXv4zJ7.xZxpZ06gIveoEtNaddS',NULL,NULL,0,NULL,1,NULL,NULL,NULL,0,0,1,'2026-02-18 15:03:31',NULL,'2026-02-18 14:59:07','2026-02-18 15:18:47',NULL,NULL,1,NULL,NULL),(22,'Inácio Mugabe','imugabe','inaciolmugabe@gmail.com',NULL,'M',NULL,NULL,NULL,NULL,NULL,NULL,'Licenciado',NULL,NULL,NULL,NULL,'vigilante','$2y$10$N2GxisEbWePhgFGutCKwDuBmhkfANuAGMZkXvKz.oPcBQLWnYbCE6',NULL,NULL,0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,NULL,'2026-02-18 15:06:42','2026-02-18 15:06:42',NULL,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_application_stats`
--

DROP TABLE IF EXISTS `v_application_stats`;
/*!50001 DROP VIEW IF EXISTS `v_application_stats`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_application_stats` AS SELECT
 1 AS `total_applications`,
  1 AS `pending_count`,
  1 AS `approved_count`,
  1 AS `rejected_count`,
  1 AS `cancelled_count`,
  1 AS `approval_rate`,
  1 AS `avg_review_hours`,
  1 AS `total_reapplies` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_applications_by_day`
--

DROP TABLE IF EXISTS `v_applications_by_day`;
/*!50001 DROP VIEW IF EXISTS `v_applications_by_day`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_applications_by_day` AS SELECT
 1 AS `date`,
  1 AS `count`,
  1 AS `approved`,
  1 AS `rejected` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_top_vigilantes`
--

DROP TABLE IF EXISTS `v_top_vigilantes`;
/*!50001 DROP VIEW IF EXISTS `v_top_vigilantes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_top_vigilantes` AS SELECT
 1 AS `id`,
  1 AS `name`,
  1 AS `email`,
  1 AS `total_applications`,
  1 AS `approved_count`,
  1 AS `rejected_count`,
  1 AS `cancelled_count`,
  1 AS `total_reapplies` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vacancy_applications`
--

DROP TABLE IF EXISTS `vacancy_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vacancy_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vacancy_id` int(11) NOT NULL,
  `vigilante_id` int(11) NOT NULL,
  `status` enum('pendente','aprovada','rejeitada','cancelada') NOT NULL DEFAULT 'pendente',
  `notes` text DEFAULT NULL,
  `applied_at` datetime NOT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `reapply_count` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vacancy_application` (`vacancy_id`,`vigilante_id`),
  KEY `fk_va_reviewed_by` (`reviewed_by`),
  KEY `idx_va_status` (`status`),
  KEY `idx_va_applied` (`applied_at`),
  KEY `idx_reapply_count` (`reapply_count`),
  KEY `idx_applications_status` (`status`,`vacancy_id`),
  KEY `idx_applications_user` (`vigilante_id`,`status`),
  CONSTRAINT `fk_va_reviewed_by` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_va_vacancy` FOREIGN KEY (`vacancy_id`) REFERENCES `exam_vacancies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_va_vigilante` FOREIGN KEY (`vigilante_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacancy_applications`
--

LOCK TABLES `vacancy_applications` WRITE;
/*!40000 ALTER TABLE `vacancy_applications` DISABLE KEYS */;
INSERT INTO `vacancy_applications` VALUES (1,3,3,'aprovada',NULL,'2026-01-31 20:34:02','2026-01-31 20:39:10',1,NULL,'2026-01-31 20:34:02','2026-01-31 20:39:10',0),(2,3,4,'aprovada',NULL,'2026-01-31 20:34:41','2026-01-31 20:39:06',1,NULL,'2026-01-31 20:34:41','2026-01-31 20:39:06',0),(3,3,5,'aprovada',NULL,'2026-01-31 20:35:30','2026-01-31 20:39:02',1,NULL,'2026-01-31 20:35:30','2026-01-31 20:39:02',0),(4,3,6,'aprovada',NULL,'2026-01-31 20:35:45','2026-01-31 20:38:58',1,NULL,'2026-01-31 20:35:45','2026-01-31 20:38:58',0),(5,3,7,'aprovada',NULL,'2026-01-31 20:36:00','2026-01-31 20:38:54',1,NULL,'2026-01-31 20:36:00','2026-01-31 20:38:54',0),(6,3,8,'aprovada',NULL,'2026-01-31 20:36:16','2026-01-31 20:38:49',1,NULL,'2026-01-31 20:36:16','2026-01-31 20:38:49',0),(7,3,9,'aprovada',NULL,'2026-01-31 20:36:32','2026-01-31 20:38:45',1,NULL,'2026-01-31 20:36:32','2026-01-31 20:38:45',0),(8,3,10,'aprovada',NULL,'2026-01-31 20:36:47','2026-01-31 20:38:41',1,NULL,'2026-01-31 20:36:47','2026-01-31 20:38:41',0),(9,4,21,'aprovada',NULL,'2026-02-18 15:04:03','2026-02-18 15:14:16',1,NULL,'2026-02-18 15:04:03','2026-02-18 15:14:16',0);
/*!40000 ALTER TABLE `vacancy_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vw_allocation_stats`
--

DROP TABLE IF EXISTS `vw_allocation_stats`;
/*!50001 DROP VIEW IF EXISTS `vw_allocation_stats`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_allocation_stats` AS SELECT
 1 AS `total_juries`,
  1 AS `total_capacity`,
  1 AS `total_allocated`,
  1 AS `slots_available`,
  1 AS `juries_with_supervisor`,
  1 AS `juries_without_supervisor`,
  1 AS `avg_workload_score`,
  1 AS `workload_std_deviation`,
  1 AS `vigilantes_without_allocation`,
  1 AS `total_candidates` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_docente_score`
--

DROP TABLE IF EXISTS `vw_docente_score`;
/*!50001 DROP VIEW IF EXISTS `vw_docente_score`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_docente_score` AS SELECT
 1 AS `docente_id`,
  1 AS `n_vigias`,
  1 AS `n_supervisoes`,
  1 AS `score` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_eligible_supervisors`
--

DROP TABLE IF EXISTS `vw_eligible_supervisors`;
/*!50001 DROP VIEW IF EXISTS `vw_eligible_supervisors`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_eligible_supervisors` AS SELECT
 1 AS `jury_id`,
  1 AS `subject`,
  1 AS `exam_date`,
  1 AS `start_time`,
  1 AS `end_time`,
  1 AS `supervisor_id`,
  1 AS `supervisor_name`,
  1 AS `email`,
  1 AS `supervisor_eligible`,
  1 AS `supervision_count`,
  1 AS `workload_score`,
  1 AS `has_conflict` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_eligible_vigilantes`
--

DROP TABLE IF EXISTS `vw_eligible_vigilantes`;
/*!50001 DROP VIEW IF EXISTS `vw_eligible_vigilantes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_eligible_vigilantes` AS SELECT
 1 AS `jury_id`,
  1 AS `subject`,
  1 AS `exam_date`,
  1 AS `start_time`,
  1 AS `end_time`,
  1 AS `vigilante_id`,
  1 AS `vigilante_name`,
  1 AS `email`,
  1 AS `supervisor_eligible`,
  1 AS `vigilance_count`,
  1 AS `supervision_count`,
  1 AS `workload_score`,
  1 AS `has_conflict` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_jury_slots`
--

DROP TABLE IF EXISTS `vw_jury_slots`;
/*!50001 DROP VIEW IF EXISTS `vw_jury_slots`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_jury_slots` AS SELECT
 1 AS `jury_id`,
  1 AS `subject`,
  1 AS `exam_date`,
  1 AS `start_time`,
  1 AS `end_time`,
  1 AS `location`,
  1 AS `room`,
  1 AS `candidates_quota`,
  1 AS `vigilantes_capacity`,
  1 AS `requires_supervisor`,
  1 AS `vigilantes_allocated`,
  1 AS `vigilantes_available`,
  1 AS `has_supervisor`,
  1 AS `supervisor_id`,
  1 AS `supervisor_name`,
  1 AS `occupancy_status` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_payment_preview`
--

DROP TABLE IF EXISTS `vw_payment_preview`;
/*!50001 DROP VIEW IF EXISTS `vw_payment_preview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_payment_preview` AS SELECT
 1 AS `user_id`,
  1 AS `nome_completo`,
  1 AS `nuit`,
  1 AS `banco`,
  1 AS `numero_conta`,
  1 AS `vacancy_id`,
  1 AS `nr_vigias`,
  1 AS `nr_supervisoes` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_payment_stats`
--

DROP TABLE IF EXISTS `vw_payment_stats`;
/*!50001 DROP VIEW IF EXISTS `vw_payment_stats`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_payment_stats` AS SELECT
 1 AS `vacancy_id`,
  1 AS `total_beneficiarios`,
  1 AS `total_vigias`,
  1 AS `total_supervisoes`,
  1 AS `valor_total`,
  1 AS `estado`,
  1 AS `dados_incompletos` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_vigilante_workload`
--

DROP TABLE IF EXISTS `vw_vigilante_workload`;
/*!50001 DROP VIEW IF EXISTS `vw_vigilante_workload`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_vigilante_workload` AS SELECT
 1 AS `user_id`,
  1 AS `name`,
  1 AS `email`,
  1 AS `workload_count`,
  1 AS `supervision_count`,
  1 AS `workload_minutes`,
  1 AS `workload_score` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_application_stats`
--

/*!50001 DROP VIEW IF EXISTS `v_application_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `v_application_stats` AS select count(0) AS `total_applications`,sum(case when `vacancy_applications`.`status` = 'pendente' then 1 else 0 end) AS `pending_count`,sum(case when `vacancy_applications`.`status` = 'aprovada' then 1 else 0 end) AS `approved_count`,sum(case when `vacancy_applications`.`status` = 'rejeitada' then 1 else 0 end) AS `rejected_count`,sum(case when `vacancy_applications`.`status` = 'cancelada' then 1 else 0 end) AS `cancelled_count`,round(sum(case when `vacancy_applications`.`status` = 'aprovada' then 1 else 0 end) * 100.0 / nullif(sum(case when `vacancy_applications`.`status` in ('aprovada','rejeitada') then 1 else 0 end),0),2) AS `approval_rate`,round(avg(case when `vacancy_applications`.`reviewed_at` is not null then timestampdiff(HOUR,`vacancy_applications`.`applied_at`,`vacancy_applications`.`reviewed_at`) else NULL end),1) AS `avg_review_hours`,sum(`vacancy_applications`.`reapply_count`) AS `total_reapplies` from `vacancy_applications` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_applications_by_day`
--

/*!50001 DROP VIEW IF EXISTS `v_applications_by_day`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `v_applications_by_day` AS select cast(`vacancy_applications`.`applied_at` as date) AS `date`,count(0) AS `count`,sum(case when `vacancy_applications`.`status` = 'aprovada' then 1 else 0 end) AS `approved`,sum(case when `vacancy_applications`.`status` = 'rejeitada' then 1 else 0 end) AS `rejected` from `vacancy_applications` where `vacancy_applications`.`applied_at` >= curdate() - interval 30 day group by cast(`vacancy_applications`.`applied_at` as date) order by cast(`vacancy_applications`.`applied_at` as date) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_top_vigilantes`
--

/*!50001 DROP VIEW IF EXISTS `v_top_vigilantes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `v_top_vigilantes` AS select `u`.`id` AS `id`,`u`.`name` AS `name`,`u`.`email` AS `email`,count(`va`.`id`) AS `total_applications`,sum(case when `va`.`status` = 'aprovada' then 1 else 0 end) AS `approved_count`,sum(case when `va`.`status` = 'rejeitada' then 1 else 0 end) AS `rejected_count`,sum(case when `va`.`status` = 'cancelada' then 1 else 0 end) AS `cancelled_count`,sum(`va`.`reapply_count`) AS `total_reapplies` from (`users` `u` join `vacancy_applications` `va` on(`u`.`id` = `va`.`vigilante_id`)) where `u`.`role` = 'vigilante' group by `u`.`id`,`u`.`name`,`u`.`email` order by count(`va`.`id`) desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_allocation_stats`
--

/*!50001 DROP VIEW IF EXISTS `vw_allocation_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_allocation_stats` AS select (select count(0) from `juries`) AS `total_juries`,(select coalesce(sum(`juries`.`vigilantes_capacity`),0) from `juries`) AS `total_capacity`,(select count(0) from `jury_vigilantes`) AS `total_allocated`,(select coalesce(sum(`juries`.`vigilantes_capacity`),0) from `juries`) - (select count(0) from `jury_vigilantes`) AS `slots_available`,(select count(0) from `juries` where `juries`.`supervisor_id` is not null) AS `juries_with_supervisor`,(select count(0) from `juries` where `juries`.`supervisor_id` is null) AS `juries_without_supervisor`,0 AS `avg_workload_score`,0 AS `workload_std_deviation`,0 AS `vigilantes_without_allocation`,(select coalesce(sum(`juries`.`candidates_quota`),0) from `juries`) AS `total_candidates` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_docente_score`
--

/*!50001 DROP VIEW IF EXISTS `vw_docente_score`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_docente_score` AS select `jv`.`vigilante_id` AS `docente_id`,sum(case when `jv`.`papel` = 'vigilante' then 1 else 0 end) AS `n_vigias`,sum(case when `jv`.`papel` = 'supervisor' then 1 else 0 end) AS `n_supervisoes`,sum(case when `jv`.`papel` = 'vigilante' then 1 when `jv`.`papel` = 'supervisor' then 2 else 0 end) AS `score` from `jury_vigilantes` `jv` group by `jv`.`vigilante_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_eligible_supervisors`
--

/*!50001 DROP VIEW IF EXISTS `vw_eligible_supervisors`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_eligible_supervisors` AS select `j`.`id` AS `jury_id`,`j`.`subject` AS `subject`,`j`.`exam_date` AS `exam_date`,`j`.`start_time` AS `start_time`,`j`.`end_time` AS `end_time`,`u`.`id` AS `supervisor_id`,`u`.`name` AS `supervisor_name`,`u`.`email` AS `email`,`u`.`supervisor_eligible` AS `supervisor_eligible`,`vw`.`supervision_count` AS `supervision_count`,`vw`.`workload_score` AS `workload_score`,case when exists(select 1 from `juries` `j2` where `j2`.`supervisor_id` = `u`.`id` and `j2`.`exam_date` = `j`.`exam_date` and `j2`.`id` <> `j`.`id` and `j2`.`start_time` < `j`.`end_time` and `j`.`start_time` < `j2`.`end_time` limit 1) then 1 else 0 end AS `has_conflict` from ((`juries` `j` join `users` `u`) left join `vw_vigilante_workload` `vw` on(`vw`.`user_id` = `u`.`id`)) where `u`.`role` = 'vigilante' and `u`.`available_for_vigilance` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_eligible_vigilantes`
--

/*!50001 DROP VIEW IF EXISTS `vw_eligible_vigilantes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_eligible_vigilantes` AS select `j`.`id` AS `jury_id`,`j`.`subject` AS `subject`,`j`.`exam_date` AS `exam_date`,`j`.`start_time` AS `start_time`,`j`.`end_time` AS `end_time`,`u`.`id` AS `vigilante_id`,`u`.`name` AS `vigilante_name`,`u`.`email` AS `email`,`u`.`supervisor_eligible` AS `supervisor_eligible`,coalesce(count(distinct `jv`.`jury_id`),0) AS `vigilance_count`,coalesce(count(distinct `js`.`id`),0) AS `supervision_count`,coalesce(count(distinct `jv`.`jury_id`),0) + coalesce(count(distinct `js`.`id`),0) * 2 AS `workload_score`,case when exists(select 1 from (`jury_vigilantes` `jv2` join `juries` `j2` on(`j2`.`id` = `jv2`.`jury_id`)) where `jv2`.`vigilante_id` = `u`.`id` and `j2`.`exam_date` = `j`.`exam_date` and `j2`.`start_time` < `j`.`end_time` and `j`.`start_time` < `j2`.`end_time` limit 1) then 1 when exists(select 1 from `juries` `j3` where `j3`.`supervisor_id` = `u`.`id` and `j3`.`exam_date` = `j`.`exam_date` and `j3`.`start_time` < `j`.`end_time` and `j`.`start_time` < `j3`.`end_time` and (`j3`.`subject` <> `j`.`subject` or `j3`.`exam_date` <> `j`.`exam_date` or `j3`.`start_time` <> `j`.`start_time` or `j3`.`end_time` <> `j`.`end_time`) limit 1) then 1 else 0 end AS `has_conflict` from (((`juries` `j` join `users` `u`) left join `jury_vigilantes` `jv` on(`jv`.`vigilante_id` = `u`.`id`)) left join `juries` `js` on(`js`.`supervisor_id` = `u`.`id`)) where `u`.`role` = 'vigilante' and `u`.`available_for_vigilance` = 1 group by `j`.`id`,`j`.`subject`,`j`.`exam_date`,`j`.`start_time`,`j`.`end_time`,`u`.`id`,`u`.`name`,`u`.`email`,`u`.`supervisor_eligible` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_jury_slots`
--

/*!50001 DROP VIEW IF EXISTS `vw_jury_slots`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_jury_slots` AS select `j`.`id` AS `jury_id`,`j`.`subject` AS `subject`,`j`.`exam_date` AS `exam_date`,`j`.`start_time` AS `start_time`,`j`.`end_time` AS `end_time`,`j`.`location` AS `location`,`j`.`room` AS `room`,`j`.`candidates_quota` AS `candidates_quota`,`j`.`vigilantes_capacity` AS `vigilantes_capacity`,`j`.`requires_supervisor` AS `requires_supervisor`,coalesce(count(`jv`.`id`),0) AS `vigilantes_allocated`,`j`.`vigilantes_capacity` - coalesce(count(`jv`.`id`),0) AS `vigilantes_available`,case when `j`.`supervisor_id` is not null then 1 else 0 end AS `has_supervisor`,`j`.`supervisor_id` AS `supervisor_id`,`s`.`name` AS `supervisor_name`,case when coalesce(count(`jv`.`id`),0) < `j`.`vigilantes_capacity` then 'incomplete' when coalesce(count(`jv`.`id`),0) = `j`.`vigilantes_capacity` then 'full' else 'overfilled' end AS `occupancy_status` from ((`juries` `j` left join `jury_vigilantes` `jv` on(`jv`.`jury_id` = `j`.`id`)) left join `users` `s` on(`s`.`id` = `j`.`supervisor_id`)) group by `j`.`id`,`j`.`subject`,`j`.`exam_date`,`j`.`start_time`,`j`.`end_time`,`j`.`location`,`j`.`room`,`j`.`candidates_quota`,`j`.`vigilantes_capacity`,`j`.`requires_supervisor`,`j`.`supervisor_id`,`s`.`name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_payment_preview`
--

/*!50001 DROP VIEW IF EXISTS `vw_payment_preview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_payment_preview` AS select `u`.`id` AS `user_id`,`u`.`name` AS `nome_completo`,`u`.`nuit` AS `nuit`,`u`.`banco` AS `banco`,`u`.`numero_conta` AS `numero_conta`,`j`.`vacancy_id` AS `vacancy_id`,sum(case when `jv`.`papel` = 'vigilante' or `jv`.`papel` is null then 1 else 0 end) AS `nr_vigias`,sum(case when `jv`.`papel` = 'supervisor' then 1 else 0 end) AS `nr_supervisoes` from ((`users` `u` join `jury_vigilantes` `jv` on(`jv`.`vigilante_id` = `u`.`id`)) join `juries` `j` on(`j`.`id` = `jv`.`jury_id`)) group by `u`.`id`,`u`.`name`,`u`.`nuit`,`u`.`banco`,`u`.`numero_conta`,`j`.`vacancy_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_payment_stats`
--

/*!50001 DROP VIEW IF EXISTS `vw_payment_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_payment_stats` AS select `p`.`vacancy_id` AS `vacancy_id`,count(distinct `p`.`user_id`) AS `total_beneficiarios`,sum(`p`.`nr_vigias`) AS `total_vigias`,sum(`p`.`nr_supervisoes`) AS `total_supervisoes`,sum(`p`.`total`) AS `valor_total`,`p`.`estado` AS `estado`,sum(case when `u`.`nuit` is null or `u`.`banco` is null or `u`.`numero_conta` is null then 1 else 0 end) AS `dados_incompletos` from (`payments` `p` join `users` `u` on(`u`.`id` = `p`.`user_id`)) group by `p`.`vacancy_id`,`p`.`estado` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_vigilante_workload`
--

/*!50001 DROP VIEW IF EXISTS `vw_vigilante_workload`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_vigilante_workload` AS select `u`.`id` AS `user_id`,`u`.`name` AS `name`,`u`.`email` AS `email`,count(distinct `jv`.`jury_id`) AS `workload_count`,count(distinct `js`.`id`) AS `supervision_count`,sum(timestampdiff(MINUTE,`j`.`start_time`,`j`.`end_time`)) AS `workload_minutes`,sum(timestampdiff(MINUTE,`j`.`start_time`,`j`.`end_time`) / 60.0) + count(distinct `js`.`id`) * 2 AS `workload_score` from (((`users` `u` left join `jury_vigilantes` `jv` on(`jv`.`vigilante_id` = `u`.`id`)) left join `juries` `j` on(`j`.`id` = `jv`.`jury_id`)) left join `juries` `js` on(`js`.`supervisor_id` = `u`.`id`)) where `u`.`role` = 'vigilante' and `u`.`available_for_vigilance` = 1 or `u`.`supervisor_eligible` = 1 group by `u`.`id`,`u`.`name`,`u`.`email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-19 13:01:18
